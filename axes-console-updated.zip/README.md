# axes Console

The axes company back-office. There is no public website: **`/` is the Console**.

## Run

```bash
cd backend
npm install
CONSOLE_PASSWORD='choose-a-long-password' npm start     # http://localhost:3000
```

Without `CONSOLE_PASSWORD`, a random password for the **super account** (`founder`) is printed in the terminal on the very first start.

Optional environment variables: `PORT`, `DATA_DIR` (where everything is stored), `PUBLIC_URL` (used in e-mailed links), `TRUST_PROXY=1` (behind a reverse proxy), `SMTP_HOST/SMTP_PORT/SMTP_USER/SMTP_PASS/SMTP_SECURE` (or set it in Ongoing → E-mail setup), `INBOUND_SECRET` (16+ characters, switches on forwarding of support e-mail), `REPORT_TZ_MIN` (minutes ahead of UTC for report deadlines, default 360 = Bangladesh).

## The home screen (your numbered picture)

| # | What | Where |
|---|------|-------|
| 1 | **Business** – projects & subsidiaries, authentication, accounts & limitations, timeline, budgets | top right |
| 2 | **Tracking** – supervision, tracker, monthly reports, activity | top middle |
| 3 | **Ongoing** – tasks (save + assign + notices), support inbox, e-mail setup | tall, left |
| 4 | **Documentation** – private vault, archive, storage plans, manuals, notes | bottom |
| 5 | axes logo (sized in `em`, so it follows the “Console” text) + Console | header |
| 6 | Name, @id, designation, years active, achievements, photo | bottom left |
| 7 | Log out | bottom right |

Tiles that are not part of your designation are shown dimmed and locked.

## Rules built in

* **One super account** (the founder). Nobody can hold, limit, delete or demote it; it has no time limits.
* The system starts with that one account. More accounts are created from Business → Accounts. A new person gets a private link to choose **their own password** (nobody sees it).
* **Authentication:** whatever a non-super account proposes — a new project, a change to a project's name/budget/timeline/team/archive status, a new account, a change to an account's designation or limits, a new designation — is only a *proposal*. It takes effect when the super account approves it **and re-enters its password** (Business → Authentication). The super account's own changes apply immediately.
* **Super account:** sees and tracks everything; creates projects *and subsidiaries* with budget, timeline and milestones; assigns any number of people to them.
* **Project Manager:** supervises/tracks all projects and subsidiaries; proposes projects (not subsidiaries) with budget and timeline; must report every project and subsidiary (documentation + finance) **by the end of the 3rd day of the next month** (Tracking → Reports shows Due / Overdue / Late); can propose new designations, members, IDs and limits — each needs the super account.
* **Support:** works the support inbox and replies by e-mail. More powers can be added later as designations.
* Extra designations can be created with a chosen set of powers; nobody can grant a power they do not hold.

## Data

JSON files in `backend/data/` (accounts, projects, tasks, reports, approvals …); each account's vault is encrypted on disk. Back up that folder.

## Designations (built in)

| Designation | Can do |
|---|---|
| **Super Account** | Everything. One only; cannot be held, limited, deleted or demoted. Authenticates every proposal with its password. |
| **Human Resources & Management** | Proposes accounts (with skills, conditions, salary), sees everyone's skills to choose teams, proposes salaries and payments, answers hiring requests. The super account authenticates. |
| **Project Manager** | Supervises only the projects assigned to them, their transactions, reports directly to the super account, orders reports from their team, applies to HR for a Junior Project Manager. |
| **Junior Project Manager** | Updates and reports on the projects they are assigned to. |
| **Subsidiaries Manager** | Manages assigned subsidiaries and their branches (revenue, cost, salary, loss, profit, withdrawals), reports to the super account, applies to HR for Branch Managers. |
| **Branch Manager** | Records the branch's transactions and reports to the subsidiaries manager. |
| **Support** | The company's main support desk for employees, clients and customers. |

Visibility: an account only sees itself, the founder, and the accounts it created or requested (Human Resources sees all). Project Managers only see projects they are assigned to, and the founder's activity is never shown to others.

Money: every transaction has a type (revenue, cost, salary, loss, withdrawal) and a reason; any can be corrected (history kept). Withdrawals and corrections notify the super account with the reason. Profit = revenue − cost − salary − loss.
