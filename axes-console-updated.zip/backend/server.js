import express from "express";
import path from "node:path";
import * as store from "./lib/store.js";
import * as users from "./lib/users.js";
import * as vault from "./lib/vault.js";
import api from "./lib/routes/api.js";
import { sendFile } from "./lib/routes/vault.js";
import { sharePage } from "./lib/pages.js";

const WEB = path.resolve(store.ROOT, "..", "web");
const PORT = Number(process.env.PORT) || 3000;

const app = express();
app.disable("x-powered-by");
if (process.env.TRUST_PROXY) app.set("trust proxy", process.env.TRUST_PROXY === "1" ? 1 : process.env.TRUST_PROXY);

app.use((req, res, next) => {
  res.set({ "X-Content-Type-Options": "nosniff", "Referrer-Policy": "strict-origin-when-cross-origin", "X-Frame-Options": "DENY", "Permissions-Policy": "camera=(), microphone=(), geolocation=()",
    "Content-Security-Policy": "default-src 'self'; img-src 'self' data: blob:; media-src 'self' blob:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'" });
  if (req.path.startsWith("/api")) res.set("Cache-Control", "no-store");
  next();
});
app.get("/health", (req, res) => res.json({ ok: true }));
app.use("/api", api());

/* ---------- a shared vault file (the only public page) ---------- */
const shareLimit = users.rateLimit(30, 15 * 60 * 1000);
const noindex = (res) => res.set({ "Cache-Control": "no-store", "X-Robots-Tag": "noindex", "Referrer-Policy": "no-referrer" });
app.get("/s/:token", shareLimit, (req, res) => { noindex(res); const f = vault.findShare(req.params.token); res.status(f ? 200 : 404).type("html").send(sharePage(f && { ...f.file, protected: !!f.share.pw }, req.params.token)); });
app.get("/s/:token/get", shareLimit, (req, res) => {
  noindex(res); const f = vault.findShare(req.params.token);
  if (!f || f.share.pw) return res.redirect("/s/" + encodeURIComponent(req.params.token));
  try { sendFile(res, vault.openShared(f.share), false); } catch (e) { res.status(e.status || 500).type("html").send(sharePage(null)); }
});
app.post("/s/:token", shareLimit, express.urlencoded({ extended: false, limit: "2kb" }), (req, res) => {
  noindex(res); const f = vault.findShare(req.params.token);
  if (!f) return res.status(404).type("html").send(sharePage(null));
  if (!vault.sharePasswordOk(f.share, req.body?.password)) return res.status(401).type("html").send(sharePage({ ...f.file, protected: true }, req.params.token, "That password is not right."));
  try { sendFile(res, vault.openShared(f.share), false); } catch (e) { res.status(e.status || 500).type("html").send(sharePage(null)); }
});

/* ---------- the Console itself is the main index ---------- */
app.get(/^\/(console|admin|developers|business)(\/.*)?$/, (req, res) => res.redirect("/"));
app.get("/support", (req, res) => (process.env.PUBLIC_SUPPORT === "0" ? res.redirect("/") : res.redirect("/support.html")));
app.use(express.static(WEB, { index: "index.html", dotfiles: "deny", setHeaders(res, f) { res.set("Cache-Control", /\.(woff2?|png|jpg|svg)$/.test(f) ? "public, max-age=86400" : "no-cache"); } }));
app.use((req, res) => res.status(404).type("text").send("Not found"));
app.use((err, req, res, next) => {
  if (err?.type === "entity.too.large" || err?.status === 413) return res.status(413).json({ error: "That is too large." });
  if (err?.type === "entity.parse.failed") return res.status(400).json({ error: "Bad data." });
  console.error(err); res.status(500).json({ error: "Server error." });
});

vault.sweep(users.all()); setInterval(() => vault.sweep(users.all()), 3600 * 1000).unref();
app.listen(PORT, () => console.log(`axes Console running on http://localhost:${PORT}`));
