/* Private vault: every account's own encrypted file store. */
import { h, $, api, run, icon, toast, copy, fmtSize, fmtMB, fmtDate, ago, meter, pageHead, empty, confirmBox, askText, overlay, drawer, menu, segmented, field, state } from "/ui.js";

const KEY = "axes:vault-view";
const ext = (n) => (n.includes(".") ? n.split(".").pop().slice(0, 4).toUpperCase() : "FILE");
const isImg = (m) => /^image\//.test(m);
export default async function (main) {
  let snap = await api("GET", "/vault"), where = "all", folder = null, q = "", mode = (() => { try { return localStorage.getItem(KEY) || "grid"; } catch { return "grid"; } })(), selected = new Set();
  const area = h("div"), side = h("div", { class: "vside" }), head = h("div"), bar = h("div");
  const quota = () => snap.plan.quotaMB * 1048576;
  const live = () => snap.files.filter((f) => !f.deletedAt), trashed = () => snap.files.filter((f) => f.deletedAt);
  const shown = () => {
    let l = where === "trash" ? trashed() : live();
    if (where === "starred") l = l.filter((f) => f.starred); else if (where === "folder") l = l.filter((f) => f.folder === folder); else if (where === "all" && !q) l = l.filter((f) => !f.folder || true);
    if (q) l = l.filter((f) => f.name.toLowerCase().includes(q));
    return where === "recent" ? [...l].sort((a, b) => b.updatedAt - a.updatedAt).slice(0, 30) : [...l].sort((a, b) => a.name.localeCompare(b.name));
  };
  let repaint = null;
  const set = (s) => { snap = s; draw(); repaint?.(); };
  const act = (fn) => run(async (...a) => set(await fn(...a)));
  const url = (f, v) => `/${location.pathname.split("/")[1]}/api/vault/files/${f.id}/download${v ? "?v=" + v : ""}`;

  function drawSide() {
    const nav = (id, label, ic, n, sub) => h("button", { class: "nav" + (sub ? " sub" : ""), "aria-current": String(where === id && (id !== "folder" || folder === n) ? "page" : "false"), onclick: () => { where = id; folder = id === "folder" ? n : null; selected.clear(); draw(); } }, icon(ic, "sm"), label);
    side.replaceChildren(nav("all", "All files", "file"), nav("recent", "Recent", "clock"), nav("starred", "Starred", "star"), ...snap.folders.map((f) => nav("folder", f.name, "folder", f.id, true)), nav("trash", "Trash", "trash"),
      h("button", { class: "nav", onclick: run(async () => { const n = await askText("New folder", "Folder name", "", "Create"); if (n) set(await api("POST", "/vault/folders", { name: n })); }) }, icon("plus", "sm"), "New folder"),
      h("div", { class: "meter-mini", style: "margin-top:14px" }, h("b", {}, snap.plan.name), meter(snap.used, quota()), `${fmtSize(snap.used)} of ${fmtMB(snap.plan.quotaMB)}`));
  }
  function card(f) {
    const sel = selected.has(f.id), toggleSel = (e) => { e.stopPropagation(); sel ? selected.delete(f.id) : selected.add(f.id); drawFiles(); drawBar(); };
    const checkbox = h("label", { class: "check box sel" + (sel ? " on" : ""), onclick: (e) => e.stopPropagation() }, h("input", { type: "checkbox", checked: sel, "aria-label": "Select " + f.name, onchange: toggleSel }));
    if (mode === "list") return h("button", { class: "li", "aria-selected": String(sel), onclick: () => open(f) }, checkbox, h("span", { class: "avatar sm" }, ext(f.name).slice(0, 3)), h("span", { class: "grow" }, h("b", {}, f.name), h("span", { class: "muted small" }, `${fmtSize(f.size)} · ${ago(f.updatedAt)}`)), f.shared && icon("link", "sm"), f.starred && icon("star", "sm"));
    return h("div", { class: "file", role: "button", tabindex: "0", "aria-selected": String(sel), onclick: () => open(f), onkeydown: (e) => e.key === "Enter" && open(f) },
      h("div", { class: "prev" }, isImg(f.mime) ? h("img", { src: url(f) + "?inline=1", alt: "", loading: "lazy" }) : h("span", { class: "ext" }, ext(f.name))), checkbox, f.starred && h("span", { class: "star" }, icon("star", "sm")),
      h("div", { class: "info" }, h("div", { class: "nm", title: f.name }, f.name), h("div", { class: "sub" }, `${fmtSize(f.size)} · ${f.deletedAt ? "in trash" : ago(f.updatedAt)}`, f.shared ? " · shared" : "")));
  }
  function drawFiles() {
    const l = shown(), title = where === "trash" ? "Trash" : where === "folder" ? snap.folders.find((f) => f.id === folder)?.name : where === "starred" ? "Starred" : where === "recent" ? "Recent" : "All files";
    head.replaceChildren(h("div", { class: "toolbar" }, h("b", { style: "font:600 18px var(--display)" }, title), h("div", { class: "grow" }),
      h("input", { class: "search", type: "search", placeholder: "Search", value: q, "aria-label": "Search files", style: "max-width:220px", oninput: (e) => { q = e.target.value.trim().toLowerCase(); drawFiles(); } }),
      segmented([["grid", "Grid", "grid"], ["list", "List", "rows"]], mode, (v) => { mode = v; try { localStorage.setItem(KEY, v); } catch {} drawFiles(); }),
      where === "folder" && h("button", { class: "ico-btn", "aria-label": "Folder options", onclick: (e) => menu(e.currentTarget, [{ label: "Rename", icon: "edit", onclick: run(async () => { const n = await askText("Rename folder", "Name", snap.folders.find((f) => f.id === folder).name); if (n) set(await api("PATCH", "/vault/folders/" + folder, { name: n })); }) },
        { label: "Delete (files go to trash)", icon: "trash", onclick: run(async () => { if (await confirmBox("Delete folder?", "Its files move to the trash.", "Delete", true)) { set(await api("DELETE", "/vault/folders/" + folder)); where = "all"; folder = null; draw(); } }) }]) }, icon("dots")),
      where === "trash" && trashed().length > 0 && h("button", { class: "btn danger sm", onclick: run(async () => { if (await confirmBox("Empty the trash?", "This cannot be undone.", "Empty", true)) set(await api("POST", "/vault/empty-trash")); }) }, "Empty trash"),
      where !== "trash" && h("button", { class: "btn", onclick: () => pick.click() }, icon("up", "sm"), "Upload")));
    area.replaceChildren(l.length ? h("div", { class: mode === "grid" ? "files-grid" : "list" }, l.map(card)) : empty(where === "trash" ? "Trash is empty" : "Nothing here", where === "trash" ? "" : "Drop files anywhere to upload."));
  }
  function drawBar() {
    selected = new Set([...selected].filter((id) => snap.files.some((f) => f.id === id)));
    if (!selected.size) return bar.replaceChildren();
    const ids = [...selected], tr = where === "trash";
    bar.replaceChildren(h("div", { class: "bulk" }, h("b", {}, `${ids.length} selected`),
      ...(tr ? [h("button", { class: "btn sm", onclick: act(async () => { selected.clear(); return api("POST", "/vault/trash", { ids, on: false }); }) }, "Restore"), h("button", { class: "btn sm", onclick: run(async () => { if (await confirmBox("Delete forever?", "", "Delete", true)) { selected.clear(); set(await api("POST", "/vault/purge", { ids })); } }) }, "Delete forever")]
        : [h("button", { class: "btn sm", onclick: act(async () => { const s = await api("PATCH", "/vault/files/" + ids[0], { starred: !snap.files.find((f) => f.id === ids[0]).starred }); return s; }), hidden: ids.length !== 1 }, "Star"),
          snap.folders.length ? h("select", { "aria-label": "Move to", onchange: act(async (e) => { const to = e.target.value === "_root" ? null : e.target.value; let s; for (const id of ids) s = await api("PATCH", "/vault/files/" + id, { folder: to }); selected.clear(); return s; }) }, h("option", { value: "" }, "Move to…"), h("option", { value: "_root" }, "Top level"), snap.folders.map((f) => h("option", { value: f.id }, f.name))) : null,
          h("button", { class: "btn sm", onclick: act(async () => { selected.clear(); return api("POST", "/vault/trash", { ids }); }) }, "Trash")]),
      h("button", { class: "ico-btn", style: "color:inherit", "aria-label": "Clear", onclick: () => { selected.clear(); drawFiles(); drawBar(); } }, icon("x", "sm"))));
  }
  function draw() { drawSide(); drawFiles(); drawBar(); }

  /* ----- file panel ----- */
  function open(f) {
    const body = h("div", { class: "db" }), d = drawer(h("div", {}, h("h2", { style: "overflow-wrap:anywhere" }, f.name), h("div", { class: "muted small" }, `${fmtSize(f.size)} · ${fmtDate(f.updatedAt)}`)), body, { onClose: () => { repaint = null; } });
    const cur = () => snap.files.find((x) => x.id === f.id), paint = () => {
      const x = cur(); if (!x) return d.close(); f = x;
      body.replaceChildren(
        isImg(x.mime) ? h("div", { class: "preview" }, h("img", { src: url(x) + "?inline=1", alt: x.name })) : /^video\//.test(x.mime) ? h("div", { class: "preview" }, h("video", { src: url(x) + "?inline=1", controls: true })) : null,
        h("div", { class: "row wrap sect" }, h("a", { class: "btn", href: url(x) }, icon("down", "sm"), "Download"),
          !x.deletedAt && h("button", { class: "btn ghost", onclick: act(async () => api("PATCH", "/vault/files/" + x.id, { starred: !x.starred })) }, icon("star", "sm"), x.starred ? "Unstar" : "Star"),
          !x.deletedAt && h("button", { class: "btn ghost", onclick: run(async () => { const n = await askText("Rename", "File name", x.name); if (n) set(await api("PATCH", "/vault/files/" + x.id, { name: n })); }) }, icon("edit", "sm"), "Rename"),
          x.deletedAt ? h("button", { class: "btn ghost", onclick: act(async () => api("POST", "/vault/trash", { ids: [x.id], on: false })) }, "Restore") : h("button", { class: "btn danger", onclick: act(async () => { d.close(); return api("POST", "/vault/trash", { ids: [x.id] }); }) }, icon("trash", "sm"), "Trash")),
        !x.deletedAt && share(x),
        h("div", { class: "sect" }, h("h3", {}, `Versions · ${x.versions.length}`), h("div", { class: "list" }, [...x.versions].reverse().map((v) => h("div", { class: "li" }, h("span", { class: "grow" }, h("b", {}, `v${v.n}`, v.n === x.cur ? " · current" : ""), h("span", { class: "muted small" }, `${fmtSize(v.size)} · ${fmtDate(v.at)}`)),
          h("a", { class: "ico-btn", href: url(x, v.n), "aria-label": "Download version" }, icon("down", "sm")),
          v.n !== x.cur && h("button", { class: "btn soft sm", onclick: act(async () => api("PATCH", "/vault/files/" + x.id, { restoreVersion: v.n })) }, "Use"),
          x.versions.length > 1 && h("button", { class: "ico-btn", "aria-label": "Delete version", onclick: run(async () => { if (await confirmBox(`Delete v${v.n}?`, "", "Delete", true)) set(await api("DELETE", `/vault/files/${x.id}/versions/${v.n}`)); }) }, icon("trash", "sm")))))));
    };
    paint(); repaint = paint;
  }
  function share(x) {
    const hours = h("select", {}, [["1", "1 hour"], ["24", "1 day"], ["168", "7 days"], ["720", "30 days"], ["0", "Never"]].map(([v, l]) => h("option", { value: v, selected: v === "168" }, l)));
    const pw = h("input", { type: "text", placeholder: "Password (optional)", autocomplete: "off" }), max = h("input", { type: "number", min: 0, placeholder: "Max downloads", "aria-label": "Max downloads" });
    const mine = snap.shares.filter((s) => s.fileId === x.id), out = h("div");
    return h("div", { class: "sect" }, h("h3", {}, "Share link"), snap.plan.sharing ? [
      h("div", { class: "grid g2", style: "margin-bottom:10px" }, hours, pw), h("div", { class: "row" }, max, h("button", { class: "btn", onclick: run(async () => { const r = await api("POST", `/vault/files/${x.id}/share`, { hours: hours.value, password: pw.value, max: max.value }); snap = await api("GET", "/vault"); await copy(r.url, "Link copied"); out.replaceChildren(h("div", { class: "copybox" }, h("span", {}, r.url), h("button", { class: "btn sm", onclick: () => copy(r.url) }, "Copy"))); draw(); repaint?.(); }) }, "Create")), out,
      mine.length ? h("div", { class: "list", style: "margin-top:8px" }, mine.map((s) => h("div", { class: "li" }, h("span", { class: "grow small" }, s.exp ? "Expires " + fmtDate(s.exp) : "No expiry", s.protected ? " · password" : "", ` · ${s.dl}${s.max ? "/" + s.max : ""} downloads`),
        h("button", { class: "btn danger sm", onclick: run(async () => { set(await api("DELETE", "/vault/shares/" + s.id)); }) }, "Revoke")))) : null] : h("p", { class: "muted small" }, "Not included in your plan."));
  }

  /* ----- upload (drop anywhere, with progress) ----- */
  const pick = h("input", { type: "file", multiple: true, hidden: true, onchange: () => { upload([...pick.files]); pick.value = ""; } });
  const tray = h("div", { class: "uploads", hidden: true });
  function upload(files) {
    if (!files.length || where === "trash") return;
    tray.hidden = false; const rows = files.map((f) => { const bar2 = h("i", { style: "width:0%" }), st = h("span", {}, "waiting"); const row = h("div", { class: "u" }, h("div", { class: "top" }, h("span", {}, f.name), st), h("div", { class: "meter" }, bar2)); tray.append(row); return { f, bar2, st, row }; });
    (async () => { for (const r of rows) {
      if (r.f.size > snap.plan.maxFileMB * 1048576) { r.st.textContent = `max ${snap.plan.maxFileMB} MB`; continue; }
      if (r.f.size > quota() - snap.used) { r.st.textContent = "no space"; continue; }
      await new Promise((ok) => { const x = new XMLHttpRequest(); x.open("POST", `/${location.pathname.split("/")[1]}/api/vault/upload?folder=${where === "folder" ? folder : ""}`); x.setRequestHeader("X-Requested-With", "axes-admin"); x.setRequestHeader("X-Filename", encodeURIComponent(r.f.name));
        x.upload.onprogress = (e) => { if (e.lengthComputable) { r.bar2.style.width = (e.loaded / e.total) * 100 + "%"; r.st.textContent = Math.round((e.loaded / e.total) * 100) + "%"; } };
        x.onload = () => { r.st.textContent = x.status === 200 ? "done" : (JSON.parse(x.responseText || "{}").error || "failed"); r.bar2.style.width = "100%"; ok(); }; x.onerror = () => { r.st.textContent = "failed"; ok(); }; x.send(r.f); }); }
      set(await api("GET", "/vault")); setTimeout(() => { tray.hidden = true; tray.replaceChildren(h("b", { class: "small" }, "Uploads")); }, 2500); })();
  }
  tray.append(h("b", { class: "small" }, "Uploads"));
  let veil = null; const dragOver = (e) => { if (e.dataTransfer?.types?.includes("Files")) { e.preventDefault(); if (!veil) { veil = h("div", { class: "dropveil" }, "Drop to upload"); document.body.append(veil); } } };
  const dragEnd = () => { veil?.remove(); veil = null; }, drop = (e) => { if (!e.dataTransfer?.files?.length) return; e.preventDefault(); dragEnd(); upload([...e.dataTransfer.files]); };
  addEventListener("dragover", dragOver); addEventListener("dragleave", (e) => { if (!e.relatedTarget) dragEnd(); }); addEventListener("drop", drop);

  main.append(pageHead("Private vault", "Encrypted, only yours."), h("div", { class: "vault" }, side, h("div", {}, head, area, bar)), pick, tray); draw();
  return () => { removeEventListener("dragover", dragOver); removeEventListener("drop", drop); tray.remove(); veil?.remove(); };
}
