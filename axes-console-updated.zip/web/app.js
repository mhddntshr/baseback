import { startConsole } from "/shell.js";

const has = (b, ...c) => b.isSuper || c.some((x) => b.caps.includes(x));
startConsole({ areas: [
  { id: "business", title: "Business", desc: "Projects, subsidiaries, achievements, salary, accounts, hiring and authentication.", icon: "brief", home: "projects",
    badge: (b) => (b.isSuper ? b.pending : b.staffOpen),
    nav: [
      { id: "projects", label: "Projects", icon: "board", show: (b) => has(b, "tracking.view", "tracking.assigned", "ventures.edit.own", "ventures.propose") },
      { id: "subsidiaries", label: "Subsidiaries", icon: "brief", show: (b) => has(b, "tracking.view", "tracking.assigned", "ventures.edit.own", "ventures.propose") },
      { id: "achievements", label: "Achievements", icon: "flag", show: (b) => has(b, "tracking.view", "tracking.assigned", "ventures.edit.own", "ventures.propose") },
      { id: "salary", label: "Salary", icon: "card" },
      { id: "approvals", label: "Authentication", icon: "stamp", badge: (b) => b.pending, warn: true, show: (b) => has(b, "ventures.propose", "accounts.propose", "salary.manage") },
      { id: "accounts", label: "Accounts & skills", icon: "users", show: (b) => has(b, "accounts.manage", "accounts.propose", "people.view") },
      { id: "staff", label: "Hiring", icon: "users", badge: (b) => b.staffOpen, warn: true, show: (b) => has(b, "hr.request", "accounts.propose") },
      { id: "designations", label: "Designations", icon: "shield", show: (b) => has(b, "accounts.manage", "accounts.propose") },
    ],
    views: { projects: () => import("/views/projects.js"), subsidiaries: () => import("/views/projects.js").then((m) => ({ default: m.subsidiaries })), achievements: () => import("/views/projects.js").then((m) => ({ default: m.achievements })), salary: () => import("/views/salary.js"), approvals: () => import("/views/approvals.js"), accounts: () => import("/views/accounts.js"), staff: () => import("/views/staff.js"), designations: () => import("/views/designations.js") } },
  { id: "tracking", title: "Tracking", desc: "Supervise projects and subsidiaries, follow money, read reports.", icon: "chart", home: "supervision",
    stat: (b) => ({ n: b.counts.ventures }),
    nav: [
      { id: "supervision", label: "Supervision", icon: "home", show: (b) => has(b, "tracking.view", "tracking.assigned") },
      { id: "tracker", label: "Tracker", icon: "flag", show: (b) => has(b, "tracking.view", "tracking.assigned") },
      { id: "reports", label: "Reports", icon: "file", badge: (b) => (b.due && b.due.missing && !b.isSuper ? b.due.missing : 0) + (b.orders || 0), warn: true, show: (b) => has(b, "tracking.view", "tracking.assigned", "reports.submit") },
      { id: "activity", label: "Activity", icon: "pulse", show: (b) => has(b, "tracking.view", "tracking.assigned") },
    ],
    views: { supervision: () => import("/views/supervision.js"), tracker: () => import("/views/projects.js").then((m) => ({ default: m.tracker })), reports: () => import("/views/reports.js"), activity: () => import("/views/system.js").then((m) => ({ default: m.activity })) } },
  { id: "ongoing", title: "Ongoing", desc: "Your task list: save a task, assign it, and get notified. Support replies by e-mail live here too.", icon: "tasks", home: "tasks",
    stat: (b) => ({ chips: [`${b.counts.tasks} open task${b.counts.tasks === 1 ? "" : "s"}`, `${b.unread} notice${b.unread === 1 ? "" : "s"}`] }),
    badge: (b) => b.unread,
    nav: [
      { id: "tasks", label: "Tasks", icon: "tasks" },
      { id: "notices", label: "Notices", icon: "bell", badge: (b) => b.unread },
      { id: "helpdesk", label: "Ask support", icon: "headset" },
      { id: "support", label: "Support inbox", icon: "headset", show: (b) => has(b, "support.reply"), badge: (b) => b.support?.new || 0 },
      { id: "email", label: "E-mail setup", icon: "mail", show: (b) => b.isSuper },
    ],
    views: { tasks: () => import("/views/tasks.js"), notices: () => import("/views/notices.js"), helpdesk: () => import("/views/helpdesk.js"), support: () => import("/views/support.js"), email: () => import("/views/system.js").then((m) => ({ default: m.email })) } },
  { id: "docs", title: "Documentation", desc: "Archives, private storage, manuals and notes — everything the company writes down.", icon: "book", home: "vault",
    nav: [
      { id: "vault", label: "Private vault", icon: "lock" },
      { id: "archive", label: "Archive", icon: "folder", show: (b) => b.isSuper || b.caps.some((c) => ["tracking.view", "ventures.edit.own", "ventures.propose"].includes(c)) },
      { id: "storage", label: "Storage plans", icon: "card", show: (b) => b.isSuper },
      { id: "manuals", label: "Manuals", icon: "book" },
      { id: "notes", label: "Notes", icon: "note" },
    ],
    views: { vault: () => import("/vault.js"), archive: () => import("/views/projects.js").then((m) => ({ default: m.archive })), storage: () => import("/views/system.js").then((m) => ({ default: m.storage })), manuals: () => import("/views/pages.js").then((m) => ({ default: m.manuals })), notes: () => import("/views/pages.js").then((m) => ({ default: m.notes })) } },
] });
