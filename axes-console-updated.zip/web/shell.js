/* The Console frame: sign in → home (four areas) → a dashboard for the area you opened. Each area only says what is in its menu. */
import { app, state, h, $, api, run, icon, avatar } from "/ui.js";

let cfg, cleanup = null, token = 0, currentArea = null, lastHash = location.hash;
export const go = (path) => { location.hash = "#/" + path; };
export const query = () => new URLSearchParams(location.hash.split("?")[1] || "");
const parse = () => { const p = location.hash.replace(/^#\/?/, "").split("?")[0].split("/").filter(Boolean).map(decodeURIComponent); return { view: p[0] || "", args: p.slice(1) }; };
const unlocked = (a) => !!state.boot.areas[a.id];
const navItems = (a) => a.nav.filter((n) => !n.show || n.show(state.boot));
const areaOf = (view) => cfg.areas.find((a) => a.nav.some((n) => n.id === view));

export function activeFor(ts) {
  const days = Math.max(0, Math.floor((Date.now() - ts) / 864e5)), m = Math.floor(days / 30.44), y = Math.floor(m / 12), mo = m % 12;
  return y ? `${y} yr${y > 1 ? "s" : ""}${mo ? ` ${mo} mo` : ""}` : m ? `${m} mo` : days < 1 ? "since today" : `${days} day${days > 1 ? "s" : ""}`;
}
const isSupport = () => state.boot?.me?.designation === "support";
const logoIcon = () => h("span", { class: "logomark", "aria-label": "axes" }, h("img", { src: "/assets/images/favicon.png", alt: "axes" }));
const brand = (extra = "") => h("span", { class: "brandmark " + extra }, h("img", { src: "/assets/images/favicon.png", alt: "" }), h("span", {}, "Console"));

/* ---------- sign in / invitation ---------- */
function loginScreen(msg) {
  state.boot = null; document.title = "Sign in · axes Console";
  const user = h("input", { type: "text", autocomplete: "username", required: true, placeholder: "Username or e-mail", "aria-label": "Username", autocapitalize: "none", spellcheck: "false" });
  const pw = h("input", { type: "password", autocomplete: "current-password", required: true, placeholder: "Password", "aria-label": "Password" });
  const err = h("p", { class: "err", role: "alert", hidden: !msg }, msg || ""), btn = h("button", { class: "go" }, "Sign in");
  const form = h("form", { onsubmit: async (e) => {
    e.preventDefault(); err.hidden = true; btn.setAttribute("aria-busy", "true");
    try { await api("POST", "/login", { username: user.value, password: pw.value }); await boot(); } catch (x) { err.textContent = x.message; err.hidden = false; pw.value = ""; pw.focus(); } finally { btn.removeAttribute("aria-busy"); }
  } }, user, pw, err, btn);
  app.replaceChildren(h("div", { class: "gate" }, h("div", { class: "gate-card" }, brand(), h("div", { class: "sub" }, "Company back-office"), form,
    h("p", { class: "fine" }, "By signing in you agree to the access rules set by the ", h("b", {}, "super account"), ". Everything you do here is recorded."))));
  user.focus();
}
async function inviteScreen(tok) {
  let info; try { info = await api("GET", "/invite/" + encodeURIComponent(tok)); } catch (e) { return app.replaceChildren(h("div", { class: "gate" }, h("div", { class: "gate-card" }, brand(), h("div", { class: "sub" }, "Link expired"), h("p", { class: "lead" }, e.message), h("a", { class: "go", href: "/" }, "Sign in")))); }
  const pw = h("input", { type: "password", autocomplete: "new-password", required: true, placeholder: "New password (10+ characters)", "aria-label": "New password" }), err = h("p", { class: "err", role: "alert", hidden: true });
  app.replaceChildren(h("div", { class: "gate" }, h("div", { class: "gate-card" }, brand(), h("div", { class: "sub" }, `Welcome, ${info.name}`), h("form", { onsubmit: async (e) => { e.preventDefault(); err.hidden = true;
    try { await api("POST", "/invite/" + encodeURIComponent(tok), { password: pw.value }); history.replaceState(null, "", "/"); await boot(); } catch (x) { err.textContent = x.message; err.hidden = false; } } },
    h("p", { class: "lead", style: "margin-bottom:0" }, `Choose a password for ${info.username}.`), pw, err, h("button", { class: "go" }, "Continue")))));
  pw.focus();
}

/* ---------- pieces shared by home and dashboards ---------- */
const doLogout = run(async () => { await api("POST", "/logout"); location.hash = ""; window.axesAdminTheme.lock(null); loginScreen(); });
const logout = () => h("button", { class: "logout signout", "aria-label": "Log out", onclick: doLogout }, icon("out", "sm"), h("span", {}, "Log out"));
const toggleTheme = () => { const next = document.documentElement.dataset.theme === "dark" ? "light" : "dark"; window.axesAdminTheme.set(next); api("PATCH", "/account", { pref: { theme: next } }).catch(() => {}); };
const themeBtn = () => { if (isSupport()) return null; const b = h("button", { class: "round", "aria-label": "Switch light / dark", title: "Light / dark", onclick: () => { toggleTheme(); paint(); } }); const paint = () => b.replaceChildren(icon(document.documentElement.dataset.theme === "dark" ? "sun" : "moon")); paint(); return b; };

/* ---------- home: the four areas ---------- */
const ILL = {
  ongoing: `<svg viewBox="0 0 320 600" preserveAspectRatio="xMidYMax slice"><rect x="52" y="232" width="330" height="420" rx="46" fill="none" stroke="var(--i1)" stroke-width="5"/><rect x="150" y="256" width="110" height="26" rx="13" fill="var(--i1)"/><rect x="82" y="318" width="300" height="340" fill="var(--i1)"/><rect x="104" y="352" width="190" height="14" rx="7" fill="var(--i3)"/><rect x="104" y="384" width="140" height="12" rx="6" fill="var(--i2)"/><circle cx="318" cy="359" r="11" fill="none" stroke="var(--i3)" stroke-width="4"/><rect x="104" y="428" width="170" height="14" rx="7" fill="var(--i3)"/><rect x="104" y="460" width="120" height="12" rx="6" fill="var(--i2)"/><circle cx="318" cy="435" r="11" fill="var(--i3)"/><rect x="82" y="520" width="190" height="78" rx="39" fill="var(--i2)"/><path d="M26 400 62 380l12 38z" fill="var(--i3)" stroke="var(--i3)" stroke-width="10" stroke-linejoin="round"/><circle cx="44" cy="360" r="20" fill="var(--i2)"/><circle cx="34" cy="560" r="26" fill="var(--i1)"/><path d="M42 320V600" stroke="var(--i2)" stroke-width="4"/></svg>`,
  tracking: `<svg viewBox="0 0 360 150" preserveAspectRatio="xMidYMin meet"><rect x="-20" y="22" width="372" height="40" rx="20" fill="var(--i2)"/><circle cx="262" cy="42" r="6" fill="var(--i1)"/><circle cx="286" cy="42" r="10" fill="var(--i1)"/><circle cx="316" cy="42" r="14" fill="var(--ib)" opacity=".85"/><rect x="-20" y="74" width="110" height="30" rx="15" fill="var(--i2)"/><circle cx="72" cy="89" r="11" fill="var(--ib)" opacity=".85"/></svg>`,
  business: `<svg viewBox="0 0 275 150" preserveAspectRatio="xMidYMin meet"><circle cx="137" cy="-48" r="150" fill="var(--i1)"/><g stroke="var(--i3)" stroke-width="4" stroke-linecap="round"><path d="M34 70l9 11M72 92l6 12M203 92l-6 12M241 70l-9 11"/></g><path d="M137 0v52" stroke="var(--i3)" stroke-width="4"/><circle cx="137" cy="4" r="10" fill="var(--i1)" stroke="var(--i3)" stroke-width="3"/><rect x="111" y="50" width="52" height="68" rx="10" fill="var(--i2)" stroke="var(--i3)" stroke-width="3"/><rect x="128" y="59" width="18" height="4" rx="2" fill="var(--i3)"/><path d="m125 88 8 8 16-18" fill="none" stroke="var(--ib)" stroke-opacity=".8" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  docs: `<svg viewBox="0 0 700 290" preserveAspectRatio="xMaxYMax slice"><path d="M110 290C190 190 380 150 560 190" fill="none" stroke="var(--i1)" stroke-width="78" stroke-linecap="round"/><g fill="var(--i3)"><circle cx="262" cy="232" r="4"/><circle cx="288" cy="226" r="4"/><circle cx="314" cy="220" r="4"/></g><rect x="40" y="170" width="150" height="120" rx="14" fill="var(--i2)" transform="rotate(-14 115 230)"/><circle cx="52" cy="176" r="12" fill="var(--i1)" stroke="var(--i3)" stroke-width="3"/><g transform="rotate(8 520 190)"><rect x="440" y="62" width="170" height="260" rx="24" fill="var(--i2)"/><rect x="462" y="86" width="100" height="14" rx="7" fill="var(--i3)"/><rect x="462" y="116" width="126" height="10" rx="5" fill="var(--i1)"/><rect x="462" y="138" width="110" height="10" rx="5" fill="var(--i1)"/><rect x="462" y="160" width="126" height="10" rx="5" fill="var(--i1)"/></g><g transform="rotate(-6 640 220)"><rect x="560" y="40" width="150" height="280" rx="24" fill="var(--i3)" opacity=".9"/><path d="M586 150h72M586 176h72M586 202h46" stroke="var(--i1)" stroke-width="10" stroke-linecap="round"/></g><circle cx="402" cy="176" r="12" fill="var(--i3)" stroke="var(--i2)" stroke-width="3"/></svg>`,
};
function tile(a) {
  const b = state.boot, ok = unlocked(a), cls = "tile t-" + a.id + (ok ? "" : " locked");
  const badge = a.badge?.(b) ? h("span", { class: "badge" }, a.badge(b)) : null, ill = h("div", { class: "ill" }); ill.innerHTML = ILL[a.id];
  const stat = a.stat?.(b);
  const body = a.id === "tracking" ? [h("div", { class: "big" }, stat?.n ?? "–"), h("h2", {}, a.title), h("p", {}, a.desc)]
    : a.id === "ongoing" ? [h("h2", {}, a.title), h("p", {}, a.desc), stat && h("div", { class: "chips", style: "margin-top:14px" }, stat.chips.map((c) => h("span", { class: "pill" }, c)))]
    : a.id === "docs" ? [h("h2", {}, a.title), h("p", {}, a.desc)] : [h("h2", {}, a.title), h("p", {}, a.desc)];
  if (!ok) body.push(h("div", { class: "lockmsg" }, icon("lock", "sm"), "Not part of your designation"));
  const attrs = ok ? { href: "#/" + (navItems(a)[0]?.id || a.home), class: cls } : { class: cls, "aria-disabled": "true", title: "Not part of your designation" };
  return h(ok ? "a" : "div", attrs, ill, badge, h("div", { class: "txt", style: a.id === "docs" ? "" : "" }, body));
}
function homeScreen() {
  currentArea = null; const m = state.boot.me; document.title = "axes Console";
  const order = ["ongoing", "tracking", "business", "docs"], byId = Object.fromEntries(cfg.areas.map((a) => [a.id, a]));
  const ach = m.stats.achievements;
  const dock = h("footer", { class: "dock" }, h("div", { class: "dock-in" },
    h("button", { class: "me", onclick: () => go("profile"), title: "Open your profile" }, avatar(m.name, "", m.photo),
      h("div", { class: "who" }, h("b", {}, m.name, h("span", {}, "@" + m.username)), h("span", { class: "l2" }, m.designationLabel),
        h("div", { class: "l3" }, h("span", { class: "pill" }, "Active " + activeFor(m.createdAt)), ach.slice(0, 2).map((x) => h("span", { class: "pill" }, "★ " + x)), ach.length > 2 && h("span", { class: "pill" }, "+" + (ach.length - 2))))),
    h("div", { class: "acts" }, themeBtn(), logout())));
  app.replaceChildren(h("div", { class: "home" }, h("header", { class: "head" }, logoIcon()), h("main", { class: "bento", id: "bento" }, order.map((id) => tile(byId[id]))), dock));
}

/* ---------- dashboard frame ---------- */
function frame(area) {
  currentArea = area.id;
  const nav = h("nav", { "aria-label": area.title, style: "display:flex;flex-direction:column;gap:4px" }, navItems(area).map((n) => h("button", { class: "nav", "data-view": n.id, onclick: () => { $(".shell").classList.remove("open"); go(n.id); } }, icon(n.icon), h("span", {}, n.label), n.badge && h("span", { class: "count" + (n.warn ? " warn" : ""), "data-badge": n.id, hidden: !n.badge(state.boot) }, n.badge(state.boot)))));
  const side = h("aside", { class: "side" }, h("button", { class: "back", onclick: () => go(""), "aria-label": "Back to Console home" }, h("span", { class: "arrow" }, icon("back", "sm"))), h("h1", { class: "area-title" }, area.title), nav);
  const top = h("header", { class: "topbar" }, h("button", { class: "round burger", "aria-label": "Menu", onclick: () => $(".shell").classList.toggle("open") }, icon("menu")),
    h("h2", { class: "ttl", id: "ttl" }, ""), h("div", { class: "grow" }), h("button", { class: "round close", "aria-label": "Close and return to Console home", title: "Close", onclick: () => go("") }, icon("x")));
  const main = h("main", { class: "main", id: "main", tabindex: "-1" });
  const root = h("div", { class: "shell" }, side, h("div", { class: "work" }, top, h("div", { class: "scroller" }, main)));
  root.addEventListener("click", (e) => { if (root.classList.contains("open") && !e.target.closest(".side") && !e.target.closest(".burger")) root.classList.remove("open"); });
  app.replaceChildren(root);
}
export function paintBadges() {
  const b = state.boot;
  const area = cfg.areas.find((a) => a.id === currentArea); if (!area) return;
  for (const n of area.nav) { const el = document.querySelector(`[data-badge="${n.id}"]`); if (el && n.badge) { const v = n.badge(b); el.textContent = v; el.hidden = !v; } }
}
export async function refresh() { try { const b = await api("GET", "/bootstrap"); state.boot = b; state.me = b.me; paintBadges(); } catch {} }

/* ---------- router ---------- */
async function route() {
  if (!state.boot) return;
  const { view, args } = parse(), my = ++token;
  cleanup?.(); cleanup = null; document.querySelectorAll(".drawer-wrap,.menu").forEach((n) => n.remove());
  if (!view) { homeScreen(); refresh().then(() => { if (!parse().view && my === token) homeScreen(); }); return; }
  const area = view === "profile" ? { id: "profile", title: "Account", nav: [{ id: "profile", label: "Profile", icon: "user" }], views: { profile: () => import("/views/profile.js") } } : areaOf(view);
  const item = area && navItems(area).find((n) => n.id === view);
  if (!area || !item || (area.id !== "profile" && !unlocked(area))) return go("");
  if (currentArea !== area.id) frame(area);
  document.querySelectorAll(".nav[data-view]").forEach((b) => b.setAttribute("aria-current", b.dataset.view === view ? "page" : "false"));
  const main = $("#main"); main.replaceChildren(); document.title = item.label + " · axes Console"; $("#ttl").textContent = item.label; 
  try { const mod = await area.views[view](); if (my !== token) return; const out = await mod.default(main, args, { go, refresh, query }); if (my === token && typeof out === "function") cleanup = out; }
  catch (e) { if (e.status !== 401) main.replaceChildren(h("div", { class: "empty" }, h("b", {}, "Couldn’t load this page"), e.message)); }
  $(".scroller")?.scrollTo(0, 0); refresh();
}
addEventListener("hashchange", () => { if (!state.boot) return; if (state.dirty && !confirm("Leave without saving?")) { history.replaceState(null, "", lastHash || "#/"); return; } state.dirty = false; lastHash = location.hash; route(); });
addEventListener("axes:signedout", () => { window.axesAdminTheme.lock(null); loginScreen("Your session ended. Please sign in again."); });

/* ---------- start ---------- */
export async function boot() {
  const inv = location.hash.match(/^#\/invite\/(.+)$/); if (inv) return inviteScreen(decodeURIComponent(inv[1]));
  const me = await fetch("/api/me", { credentials: "same-origin" }).then((r) => r.json()).catch(() => ({}));
  if (!me.loggedIn) return loginScreen();
  const b = await api("GET", "/bootstrap"); state.boot = b; state.me = b.me; state.passwordFromEnv = b.passwordFromEnv; currentArea = null;
  if (b.me.designation === "support") window.axesAdminTheme.lock("support"); else { window.axesAdminTheme.lock(null); if (b.me.pref?.theme) window.axesAdminTheme.set(b.me.pref.theme); }
  lastHash = location.hash; await route();
}
export function startConsole(config) { cfg = config; boot().catch((e) => app.replaceChildren(h("p", { style: "padding:24px" }, "Could not load: " + e.message))); }
