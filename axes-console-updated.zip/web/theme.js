/* Runs first so the right theme is on <html> before anything is painted. Preference: light | dark | auto (follows the device). */
(function () {
  var KEY = "axes:admin-theme", root = document.documentElement, mq = matchMedia("(prefers-color-scheme: dark)");
  function pref() { try { var v = localStorage.getItem(KEY); return v === "light" || v === "dark" ? v : "dark"; } catch (e) { return "dark"; } }
  var locked = false;
  function apply() { var p = locked ? "light" : pref(), t = p === "auto" ? (mq.matches ? "dark" : "light") : p; root.setAttribute("data-theme", t); root.style.colorScheme = t; var m = document.querySelector('meta[name="theme-color"]'); if (m) m.setAttribute("content", t === "dark" ? "#0f0f0f" : "#ffffff"); }
  window.axesAdminTheme = { get: function () { return locked ? "light" : pref(); }, locked: function () { return locked; }, lock: function (role) { locked = !!role; if (role) root.setAttribute("data-role", role); else root.removeAttribute("data-role"); apply(); }, _pref: pref, set: function (v) { if (locked) return; try { localStorage.setItem(KEY, v); } catch (e) {} apply(); } };
  mq.addEventListener && mq.addEventListener("change", apply); apply();
})();
