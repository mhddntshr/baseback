/* Profile: your photo, details, appearance and password. */
import { h, state, api, run, icon, toast, fmtDate, avatar, pageHead, field } from "/ui.js";
import { activeFor, refresh } from "/shell.js";
import { limitText } from "/views/approvals.js";

/** Crop to a centred square and shrink, so the upload is small. */
async function squareJpeg(file, size = 320) {
  const bmp = await createImageBitmap(file), s = Math.min(bmp.width, bmp.height), c = document.createElement("canvas"); c.width = c.height = size;
  c.getContext("2d").drawImage(bmp, (bmp.width - s) / 2, (bmp.height - s) / 2, s, s, 0, 0, size, size);
  return new Promise((ok, no) => c.toBlob((b) => (b ? ok(b) : no(new Error("Could not read that picture."))), "image/jpeg", 0.86));
}
export default async function (main) {
  const m = state.boot.me, d = { name: m.name, email: m.email }, box = h("div");
  const draw = () => {
    const me = state.boot.me, st = me.stats;
    const file = h("input", { type: "file", accept: "image/jpeg,image/png,image/webp", hidden: true, onchange: run(async (e) => { const f = e.target.files[0]; if (!f) return; const blob = await squareJpeg(f); await api("POST", "/account/photo", blob, { headers: { "Content-Type": "image/jpeg" }, raw: true }); await refresh(); toast("Photo updated ✓"); draw(); }) });
    const cur = h("input", { type: "password", autocomplete: "current-password" }), nw = h("input", { type: "password", autocomplete: "new-password", placeholder: "10+ characters" });
    box.replaceChildren(
      h("div", { class: "card", style: "display:flex;gap:22px;align-items:center;flex-wrap:wrap" }, avatar(me.name, "xl", me.photo), h("div", { class: "grow" }, h("h2", { style: "margin:0" }, me.name), h("p", { class: "muted" }, `@${me.username} · ${me.designationLabel}`), h("div", { class: "row wrap", style: "margin-top:10px" }, file, h("button", { class: "btn ghost sm", onclick: () => file.click() }, icon("image", "sm"), me.photo ? "Change photo" : "Add photo"), me.photo && h("button", { class: "btn ghost sm", onclick: run(async () => { await api("DELETE", "/account/photo"); await refresh(); toast("Photo removed"); draw(); }) }, "Remove"))),
        h("div", { class: "row wrap", style: "gap:8px" }, h("span", { class: "pill" }, "Active " + activeFor(me.createdAt)), h("span", { class: "pill" }, "Since " + fmtDate(me.createdAt)))),
      h("div", { class: "grid g4", style: "margin-top:14px" }, [[st.tasksDone, "Tasks done"], [st.projects, "Projects assigned"], [st.reports, "Reports sent"], [st.reportsOnTime, "Reports on time"]].map(([n, l]) => h("div", { class: "kpi" }, h("div", { class: "n" }, n), h("div", { class: "l" }, l)))),
      h("div", { class: "card", style: "margin-top:14px" }, h("h2", {}, "Achievements"), st.achievements.length ? h("div", { class: "row wrap" }, st.achievements.map((a) => h("span", { class: "pill ok" }, "★ " + a))) : h("p", { class: "muted small" }, "They appear as you finish tasks, send reports and deliver projects.")),
      h("div", { class: "card", style: "margin-top:14px" }, h("h2", {}, "Details"), h("div", { class: "grid g2" }, field("Name", h("input", { type: "text", value: d.name, oninput: (e) => { d.name = e.target.value; } })), field("E-mail", h("input", { type: "email", value: d.email, oninput: (e) => { d.email = e.target.value; } }))),
        h("div", { class: "row", style: "margin-top:12px" }, h("button", { class: "btn", onclick: run(async () => { await api("PATCH", "/account", d); await refresh(); toast("Saved ✓"); draw(); }) }, "Save"))),
      h("div", { class: "card", style: "margin-top:14px" }, h("h2", {}, "Access"), h("dl", { class: "kv" }, [["Designation", me.designationLabel], ["Limitations", me.kind === "super" ? "None — the super account is never limited" : limitText(me.limits)], ["Last sign-in", me.lastLogin ? fmtDate(me.lastLogin) : "—"]].flatMap(([k, v]) => [h("dt", {}, k), h("dd", {}, v)]))),
      h("div", { class: "card", style: "margin-top:14px" }, h("h2", {}, "Password"), state.passwordFromEnv ? h("p", { class: "muted small" }, "This password is set by CONSOLE_PASSWORD on your host.") : [h("div", { class: "grid g2" }, field("Current password", cur), field("New password", nw)),
        h("div", { class: "row wrap", style: "margin-top:12px" }, h("button", { class: "btn", onclick: run(async () => { await api("POST", "/account/password", { current: cur.value, next: nw.value }); cur.value = nw.value = ""; toast("Password changed ✓"); }) }, "Change password"), h("button", { class: "btn ghost", onclick: run(async () => { await api("POST", "/account/signout-all"); toast("Other devices signed out"); }) }, "Sign out other devices"))]));
  };
  main.append(pageHead("Profile", "Your photo, details and password.")); main.append(box); draw();
}
