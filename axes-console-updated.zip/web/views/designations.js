/* Designations: built-in (Super, Project Manager, Support) plus ones the super account — or a proposal it authenticates — adds. */
import { h, state, api, run, icon, toast, pageHead, field, overlay, confirmBox } from "/ui.js";

export default async function (main) {
  const isSuper = state.boot.isSuper, box = h("div");
  const mine = new Set(state.boot.caps), capLabel = (id) => state.boot.grantable.find((g) => g.id === id)?.label || id;
  const SUPER_TXT = ["Everything — and it authenticates all proposals", "Cannot be held, limited, demoted or deleted"];
  const draw = () => box.replaceChildren(h("div", { class: "grid auto" }, state.boot.designations.map((d) => h("div", { class: "kpi", style: "align-items:flex-start;gap:10px;text-align:left" },
    h("div", { class: "row", style: "width:100%" }, h("b", { class: "grow", style: "font-size:17px" }, d.label), d.builtin ? h("span", { class: "pill" }, "Built-in") : h("span", { class: "pill info" }, "Custom")),
    h("ul", { class: "small", style: "padding-left:18px;margin:0;color:var(--ink-soft);display:grid;gap:4px" }, (d.id === "super" ? SUPER_TXT : d.caps.map(capLabel)).map((t) => h("li", {}, t)), d.id !== "super" && !d.caps.length && h("li", { class: "muted" }, "Tasks, notices, notes, manuals and a private vault only")),
    isSuper && !d.builtin && h("button", { class: "btn ghost sm", onclick: run(async () => { if (!(await confirmBox(`Remove “${d.label}”?`, "Only possible when no account uses it.", "Remove", true))) return; await api("DELETE", "/designations/" + d.id); state.boot.designations = state.boot.designations.filter((x) => x.id !== d.id); toast("Removed"); draw(); }) }, "Remove")))),
    h("p", { class: "muted small", style: "margin-top:16px" }, "Every account can always use tasks, notices, notes, manuals and its own private vault."));
  function create() {
    const d = { label: "", caps: [] };
    const caps = h("div", { class: "list" }, state.boot.grantable.map((g) => { const ok = isSuper || mine.has(g.id); return h("label", { class: "check box li", style: ok ? "" : "opacity:.45" }, h("input", { type: "checkbox", disabled: !ok, onchange: (e) => { d.caps = e.target.checked ? [...d.caps, g.id] : d.caps.filter((x) => x !== g.id); } }), h("span", { class: "grow" }, g.label), !ok && h("span", { class: "tiny muted" }, "you don’t hold this")); }));
    const dlg = overlay([h("h2", {}, isSuper ? "New designation" : "Propose a designation"), !isSuper && h("div", { class: "banner" }, icon("stamp", "sm"), h("span", { class: "grow" }, "You can only give powers you hold yourself. The super account authenticates it.")),
      field("Name", h("input", { type: "text", placeholder: "e.g. Finance Analyst", oninput: (e) => { d.label = e.target.value; } })), h("div", { class: "field" }, h("label", {}, "Powers"), caps),
      h("div", { class: "foot" }, h("button", { class: "btn ghost", onclick: () => dlg.close() }, "Cancel"), h("button", { class: "btn", onclick: run(async () => { const r = await api("POST", "/designations", d); dlg.close(); if (r.pending) toast("Sent to the super account for authentication ✓"); else { toast("Created ✓"); const b = await api("GET", "/bootstrap"); state.boot = b; draw(); } }) }, isSuper ? "Create" : "Send for authentication"))], { wide: true });
  }
  main.append(pageHead("Designations", "Who can do what. Built-in designations cannot be edited."), h("div", { class: "toolbar" }, h("div", { class: "grow" }), h("button", { class: "btn", onclick: create }, icon("plus", "sm"), isSuper ? "New designation" : "Propose designation")), box); draw();
}
