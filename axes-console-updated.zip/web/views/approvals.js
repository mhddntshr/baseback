/* Authentication: everything proposed by others waits here for the super account. */
import { h, state, api, run, icon, toast, ago, fmtDate, pageHead, empty, field, overlay, copy, whoAvatar, avatar, personName } from "/ui.js";
import { refresh } from "/shell.js";

const money = (n) => `${Math.round(n || 0).toLocaleString()} ${state.boot.currency}`;
const names = (ids) => (ids || []).map(personName).filter(Boolean).join(", ") || "—";
const capLabel = (id) => state.boot.grantable.find((g) => g.id === id)?.label || id;
const label = { startDate: "Start date", targetDate: "Target date", budget: "Budget", name: "Name", summary: "Summary", kind: "Type", team: "Team", milestones: "Milestones", archived: "Archive", designation: "Designation", limits: "Limits", email: "E-mail" };
const val = (k, v) => k === "budget" ? money(v) : k === "team" ? names(v) : k === "milestones" ? (v.length ? v.map((m) => `${m.title}${m.date ? " (" + m.date + ")" : ""}`).join(", ") : "none") : k === "archived" ? (v ? "Archive it" : "Restore it") : k === "designation" ? (state.boot.designations.find((d) => d.id === v)?.label || v) : k === "limits" ? limitText(v) : String(v || "—");
export const limitText = (l) => { if (!l) return "No limits"; const p = []; if (l.validFrom || l.validUntil) p.push(`${l.validFrom || "…"} → ${l.validUntil || "…"}`); if (l.days?.length) p.push(l.days.map((d) => "SMTWTFS"[d] + ["un", "on", "ue", "ed", "hu", "ri", "at"][d]).join(" ")); if (l.from && l.to) p.push(`${l.from}–${l.to}`); if (l.maxSessionHours) p.push(`${l.maxSessionHours} h sessions`); return p.join(" · ") || "No limits"; };
const lines = (a) => {
  const p = a.payload;
  if (a.diff?.length && a.type !== "account.create") return a.diff.map((d) => [d.field, d.from !== undefined ? `${d.from}   →   ${d.to}` : d.to]);
  if (a.type === "venture.create") return [["Type", { subsidiary: "Subsidiary", branch: "Branch" }[p.kind] || "Project"], ["Budget", money(p.budget)], ["Timeline", `${p.startDate || "…"} → ${p.targetDate || "…"}`], ["Milestones", val("milestones", p.milestones)], ["Suggested team", names(p.team)], ["About", p.summary || "—"]];
  if (a.type === "venture.update") return Object.entries(p.patch).map(([k, v]) => [label[k] || k, val(k, v)]);
  if (a.type === "account.create") return [["Name", p.name], ["Username", p.username], ["E-mail", p.email || "—"], ["Designation", val("designation", p.designation)], ...(p.skills?.length ? [["Skills", p.skills.join(", ")]] : []), ...(p.salary?.amount ? [["Monthly salary", money(p.salary.amount)]] : []), ...(p.conditions ? [["Conditions", p.conditions]] : []), ["Limits", limitText(p.limits)]];
  if (a.type === "account.update") return Object.entries(p.patch).map(([k, v]) => [label[k] || k, val(k, v)]);
  if (a.type === "designation.create") return [["Name", p.label], ["Powers", p.caps.length ? p.caps.map(capLabel).join("; ") : "None"]];
  return [];
};
const pillFor = (s) => h("span", { class: "pill " + ({ pending: "warn", approved: "ok", rejected: "bad" }[s] || "") }, { pending: "Waiting", approved: "Authorised", rejected: "Rejected", cancelled: "Withdrawn" }[s] || s);

function inviteDialog(r) {
  const box = h("input", { type: "text", readonly: true, value: r.inviteUrl, onfocus: (e) => e.target.select() });
  const d = overlay([h("h2", {}, "Account created"), h("p", {}, `Give ${r.username} this private link so they can choose a password. It works for 3 days.` + (r.emailed ? " It was also e-mailed." : "")), h("div", { class: "row" }, box, h("button", { class: "btn", onclick: () => copy(r.inviteUrl, "Link copied") }, "Copy")), h("div", { class: "foot" }, h("button", { class: "btn", onclick: () => d.close() }, "Done"))]);
}
function decide(a, done) {
  const note = h("input", { type: "text", placeholder: "Note (optional)" }), pw = h("input", { type: "password", autocomplete: "current-password", placeholder: "Your super account password" });
  const go = (decision) => run(async () => {
    if (!pw.value) { toast("Enter your password to authenticate.", true); pw.focus(); return; }
    const r = await api("POST", `/approvals/${a.id}/decide`, { decision, password: pw.value, note: note.value }); d.close(); toast(decision === "approve" ? "Authorised ✓" : "Rejected"); await refresh(); if (decision === "approve" && r.result?.inviteUrl) inviteDialog(r.result); done();
  });
  const d = overlay([h("h2", {}, "Authenticate"), h("p", {}, `${a.byName} proposed: ${a.summary}`),
    h("dl", { class: "kv" }, lines(a).flatMap(([k, v]) => [h("dt", {}, k), h("dd", {}, v)])), field("Your note", note), field("Confirm with your password", pw, "Only the super account can authorise changes."),
    h("div", { class: "foot" }, h("button", { class: "btn ghost", onclick: () => d.close() }, "Cancel"), h("button", { class: "btn danger", onclick: go("reject") }, "Reject"), h("button", { class: "btn", onclick: go("approve") }, "Authorise"))]);
}
export default async function (main) {
  let list = await api("GET", "/approvals"), tab = "pending";
  const box = h("div"), tabs = h("div");
  const draw = () => {
    const rows = list.filter((a) => (tab === "pending") === (a.status === "pending"));
    tabs.replaceChildren(h("div", { class: "seg", style: "margin-bottom:16px" }, [["pending", `Waiting (${list.filter((a) => a.status === "pending").length})`], ["history", "History"]].map(([k, l]) => h("button", { "aria-pressed": String(tab === k), onclick: () => { tab = k; draw(); } }, l))));
    box.replaceChildren(rows.length ? h("div", { class: "list" }, rows.map((a) => h("details", { class: "item" }, h("summary", {}, h("span", { class: "grow" }, h("b", { class: "title" }, a.summary), h("span", { class: "muted small", style: "display:block" }, `${a.typeLabel} · ${a.byName} · ${ago(a.createdAt)}`)), pillFor(a.status)),
      h("div", { class: "body" }, h("dl", { class: "kv" }, lines(a).flatMap(([k, v]) => [h("dt", {}, k), h("dd", {}, v)])),
        a.decidedAt && h("p", { class: "muted small" }, `${a.status === "approved" ? "Authorised" : "Decided"} by ${a.decidedByName} · ${fmtDate(a.decidedAt)}${a.note ? " · “" + a.note + "”" : ""}`),
        a.status === "pending" && h("div", { class: "row", style: "margin-top:12px" }, state.boot.isSuper ? h("button", { class: "btn", onclick: () => decide(a, reload) }, icon("stamp", "sm"), "Review & authenticate") : a.by === state.me.id && h("button", { class: "btn ghost", onclick: run(async () => { await api("POST", `/approvals/${a.id}/cancel`); toast("Withdrawn"); reload(); }) }, "Withdraw")))))) : empty(tab === "pending" ? "Nothing waiting" : "No history yet", tab === "pending" ? (state.boot.isSuper ? "New projects, budget or timeline changes, accounts and designations proposed by others appear here." : "Proposals you send appear here until the super account decides.") : ""));
  };
  const reload = async () => { list = await api("GET", "/approvals"); draw(); };
  main.append(pageHead("Authentication", state.boot.isSuper ? "Proposals from your team. Nothing changes until you authenticate it." : "Your proposals and what the super account decided."), tabs, box); draw();
}
