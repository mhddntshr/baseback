/* Tracking → Reports: every project and subsidiary reports documentation + finance by the 3rd of the next month. */
import { h, state, api, run, icon, toast, fmtDate, ago, pageHead, empty, field, overlay, who } from "/ui.js";

const money = (n) => `${Math.round(n || 0).toLocaleString()} ${state.boot.currency}`;
const monthName = (p) => new Date(p + "-01T00:00:00Z").toLocaleString([], { month: "long", year: "numeric", timeZone: "UTC" });
const stateUi = { submitted: ["ok", "On time"], late: ["warn", "Sent late"], overdue: ["bad", "Overdue"], open: ["info", "Due"] };

export default async function (main) {
  let period = null, data;
  const box = h("div"), head = h("div");
  const load = async () => { data = await api("GET", "/reports" + (period ? "?period=" + period : "")); period = data.period; draw(); };
  const kindName = (k) => ({ subsidiary: "Subsidiary", branch: "Branch" }[k] || "Project");
  const reportOf = (row) => data.reports.find((r) => r.ventureId === row.ventureId);
  function form(row) {
    const ex = reportOf(row), snap = data.snapshot[row.ventureId] || { revenue: 0, cost: 0, profit: 0, budget: 0 };
    const docs = h("textarea", { rows: 5, placeholder: "What documentation was produced or updated this month? Contracts, specs, plans, minutes, approvals…" }, ex?.docs || ""), note = h("textarea", { rows: 3, placeholder: "Anything to explain about the finance this month?" }, ex?.financeNote || "");
    const dlg = overlay([h("h2", {}, `${row.name} · ${monthName(period)}`), h("p", { class: "muted small" }, data.orders.mine.some((o) => o.ventureId === row.ventureId && o.period === period) ? "This report was ordered. You can submit it now." : `Due by the end of day ${data.deadlineDay} of the next month (${fmtDate(data.due)}).`),
      field("Documentation", docs), h("div", { class: "sect" }, h("h3", {}, "Finance (from the project ledger)"), h("div", { class: "grid g4" }, [["Revenue", snap.revenue], ["Cost", snap.cost], ["Salary", snap.salary], ["Loss", snap.loss], ["Profit", snap.profit], ["Withdrawn", snap.withdrawal], ["Budget", snap.budget]].map(([l, n]) => h("div", { class: "kpi", style: "padding:12px" }, h("div", { class: "n", style: "font-size:16px" }, money(n)), h("div", { class: "l" }, l))))), field("Finance note", note),
      h("div", { class: "foot" }, h("button", { class: "btn ghost", onclick: () => dlg.close() }, "Cancel"), h("button", { class: "btn", onclick: run(async () => { await api("POST", "/reports", { ventureId: row.ventureId, period, docs: docs.value, financeNote: note.value }); dlg.close(); toast("Report saved ✓"); load(); }) }, ex ? "Update report" : "Submit report"))], { wide: true });
  }
  function read(row) {
    const r = reportOf(row); if (!r) return;
    const note = h("input", { type: "text", placeholder: "Review note (optional)" });
    const dlg = overlay([h("h2", {}, `${r.ventureName} · ${monthName(r.period)}`), h("p", { class: "muted small" }, `${r.byName} · ${fmtDate(r.submittedAt)} · ${r.onTime ? "on time" : "late"}${r.status === "reviewed" ? " · reviewed by " + r.review.byName : ""}`),
      h("div", { class: "sect" }, h("h3", {}, "Documentation"), h("p", { style: "white-space:pre-wrap" }, r.docs)),
      h("div", { class: "sect" }, h("h3", {}, "Finance"), h("dl", { class: "kv" }, [["Revenue", money(r.finance.revenue)], ["Cost", money(r.finance.cost)], ["Salary", money(r.finance.salary || 0)], ["Loss", money(r.finance.loss || 0)], ["Profit", money(r.finance.profit)], ["Withdrawn", money(r.finance.withdrawal || 0)], ["Budget", money(r.finance.budget)], ["Note", r.financeNote || "—"]].flatMap(([k, v]) => [h("dt", {}, k), h("dd", {}, v)]))),
      r.review?.note && h("p", { class: "muted small" }, "Review: " + r.review.note),
      h("div", { class: "foot" }, h("button", { class: "btn ghost", onclick: () => dlg.close() }, "Close"),
        data.canSubmit && r.status !== "reviewed" && h("button", { class: "btn ghost", onclick: () => { dlg.close(); form(row); } }, "Edit"),
        state.boot.isSuper && (r.status === "reviewed" ? h("button", { class: "btn ghost", onclick: run(async () => { await api("POST", `/reports/${r.id}/review`, { reopen: true }); dlg.close(); toast("Reopened"); load(); }) }, "Reopen") : [note, h("button", { class: "btn", onclick: run(async () => { await api("POST", `/reports/${r.id}/review`, { note: note.value }); dlg.close(); toast("Marked as reviewed ✓"); load(); }) }, "Mark reviewed")]))], { wide: true });
  }
  async function orderDialog() {
    const vs = (await api("GET", "/ventures")).items.filter((v) => !v.archivedAt), d = { ventureId: vs[0]?.id || "", to: "", period: data.periods[0], note: "" };
    if (!vs.length) return toast("There is nothing to ask a report on yet.", true);
    const person = h("select", { onchange: (e) => { d.to = e.target.value; } }), fill = () => { const v = vs.find((x) => x.id === d.ventureId), ids = (v?.team || []).filter((id) => id !== state.me.id && who(id)); d.to = ids[0] || ""; person.replaceChildren(...(ids.length ? ids.map((id) => h("option", { value: id }, who(id).name + " · " + who(id).designation)) : [h("option", { value: "" }, "No one on this team yet")])); };
    const venture = h("select", { onchange: (e) => { d.ventureId = e.target.value; fill(); } }, vs.map((v) => h("option", { value: v.id }, v.name))); fill();
    const months = h("select", { onchange: (e) => { d.period = e.target.value; } }, [...new Set([data.now || "", ...data.periods])].filter(Boolean).map((p) => h("option", { value: p }, monthName(p))));
    const dlg = overlay([h("h2", {}, "Order a report"), h("p", { class: "muted small" }, "The person can submit it at any time, even before the normal deadline or for the month still running."), field("Project / subsidiary", venture), field("Ask", person), field("Month", months), field("Note (optional)", h("input", { type: "text", oninput: (e) => { d.note = e.target.value; } })),
      h("div", { class: "foot" }, h("button", { class: "btn ghost", onclick: () => dlg.close() }, "Cancel"), h("button", { class: "btn", onclick: run(async () => { await api("POST", "/reports/order", d); dlg.close(); toast("Ordered ✓"); load(); }) }, "Send order"))]);
  }
  function draw() {
    const orders = data.orders.mine, issued = data.orders.issued;
    head.replaceChildren(orders.length ? h("div", { class: "banner", style: "flex-direction:column;align-items:stretch;gap:8px;margin-bottom:14px" }, h("b", {}, "Reports asked of you"), orders.map((o) => h("div", { class: "row wrap" }, h("span", { class: "grow small" }, `${o.byName} asked for ${o.ventureName} · ${monthName(o.period)}${o.note ? " — " + o.note : ""}`), h("button", { class: "btn sm", onclick: run(async () => { period = o.period; await load(); const row = data.rows.find((r) => r.ventureId === o.ventureId); row ? form(row) : toast("Open the project first", true); }) }, "Write it now")))) : null,
      h("div", { class: "toolbar" }, h("select", { "aria-label": "Month", onchange: (e) => { period = e.target.value; load(); } }, (data.periods.includes(period) ? data.periods : [period, ...data.periods]).map((p) => h("option", { value: p, selected: p === period }, monthName(p)))), h("span", { class: "muted small" }, `Due ${fmtDate(data.due)}`), h("div", { class: "grow" }), data.canOrder && h("button", { class: "btn ghost", onclick: orderDialog }, icon("plus", "sm"), "Order a report")),
      issued.length ? h("details", { class: "item", style: "margin-bottom:14px" }, h("summary", {}, h("span", { class: "title" }, "Reports I ordered"), h("span", { class: "muted small" }, `${issued.filter((o) => !o.doneAt).length} waiting`)), h("div", { class: "body" }, issued.map((o) => h("div", { class: "li" }, h("span", { class: "grow small" }, `${o.toName} · ${o.ventureName} · ${monthName(o.period)}`), h("span", { class: "pill " + (o.doneAt ? "ok" : "warn") }, o.doneAt ? "Submitted" : "Waiting"), !o.doneAt && h("button", { class: "ico-btn", "aria-label": "Cancel order", onclick: run(async () => { await api("DELETE", "/reports/order/" + o.id); load(); }) }, icon("x", "sm")))))) : null);
    const total = data.rows.length, done = data.rows.filter((r) => r.state === "submitted" || r.state === "late").length;
    box.replaceChildren(h("p", { class: "small", style: "margin-bottom:12px" }, total ? `${done} of ${total} reported for ${monthName(period)}.` : ""),
      data.rows.length ? h("div", { class: "table rtable" }, h("div", { class: "thead" }, ["Project / subsidiary", "Type", "Status", "Reported by", ""].map((t) => h("div", {}, t))),
        data.rows.map((row) => { const [cls, txt] = stateUi[row.state]; return h("div", { class: "tr", style: "cursor:default" }, h("div", { class: "cell" }, h("b", {}, row.name)), h("div", { class: "cell" }, kindName(row.kind)), h("div", { class: "cell" }, h("span", { class: "pill " + cls }, txt)),
          h("div", { class: "cell" }, row.report ? `${row.report.byName} · ${ago(row.report.submittedAt)}` : "—"),
          h("div", { class: "cell", style: "display:flex;gap:6px;justify-content:flex-end;overflow:visible" }, row.report && h("button", { class: "btn ghost sm", onclick: () => read(row) }, row.report.status === "reviewed" ? "Reviewed" : "Read"), !row.report && data.canSubmit && h("button", { class: "btn sm", onclick: () => form(row) }, "Write report"))); }))
        : empty("Nothing to report for this month", "Only projects and subsidiaries that already existed in that month need a report."));
  }
  main.append(pageHead("Monthly reports", `Documentation and finance for every project and subsidiary, by the ${3}rd of the next month.`), head, box); await load();
}
