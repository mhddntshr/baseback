/* Ongoing → Tasks: save a task, assign it (people are notified), move it along. */
import { h, state, api, run, icon, toast, can, fmtDay, whoAvatar, avatar, pageHead, empty, field, overlay, confirmBox, segmented, personName } from "/ui.js";
import { refresh } from "/shell.js";

const COLS = [["todo", "To do"], ["doing", "In progress"], ["done", "Done"]], PRI = { low: "Low", normal: "Normal", high: "High" };
const today = () => new Date().toISOString().slice(0, 10);

export default async function (main) {
  const me = state.me.id, isSuper = state.boot.isSuper, canAssign = isSuper || can("tasks.assign");
  let items = await api("GET", "/tasks"), ventures = []; try { ventures = (await api("GET", "/ventures")).items.filter((v) => !v.archivedAt); } catch {}
  let scope = "mine"; const box = h("div");
  const reload = async () => { items = await api("GET", "/tasks"); await refresh(); draw(); };
  const shown = () => items.filter((t) => scope === "all" || (scope === "mine" ? t.assignees.includes(me) : t.createdBy === me && !(t.assignees.length === 1 && t.assignees[0] === me)));
  const card = (t) => { const late = t.status !== "done" && t.due && t.due < today();
    return h("button", { class: "tcard" + (t.status === "done" ? " done" : ""), onclick: () => edit(t) }, h("b", {}, t.title), t.details && h("div", { class: "tiny muted", style: "margin-top:4px" }, t.details.slice(0, 90)),
      h("div", { class: "f" }, h("span", { class: "stack-av" }, t.assignees.slice(0, 3).map((id) => whoAvatar(id, "sm"))), t.priority === "high" && h("span", { class: "pill bad" }, "High"), t.due && h("span", { class: "pill " + (late ? "bad" : "") }, (late ? "Overdue · " : "Due ") + fmtDay(Date.parse(t.due))), t.projectName && h("span", { class: "pill" }, t.projectName), t.createdBy !== me && h("span", { class: "tiny" }, "from " + t.createdByName))); };
  function draw() {
    const l = shown();
    box.replaceChildren(l.length ? h("div", { class: "board", style: "grid-auto-columns:minmax(260px,1fr)" }, COLS.map(([k, label]) => { const c = l.filter((t) => t.status === k); return h("div", { class: "tcol" }, h("h3", {}, label, h("span", { class: "muted" }, c.length)), c.map(card), !c.length && h("p", { class: "tiny muted", style: "padding:6px 8px" }, "—")); })) : empty("No tasks here", scope === "mine" ? "Save a task for yourself, or have someone assign one to you." : "Nothing in this view."));
  }
  function form(t) {
    const full = !t || isSuper || t.createdBy === me, d = t ? { title: t.title, details: t.details, due: t.due, priority: t.priority, status: t.status, project: t.project, assignees: [...t.assignees] } : { title: "", details: "", due: "", priority: "normal", status: "todo", project: "", assignees: [me] };
    const people = h("div", { class: "chips" }, state.boot.people.filter((p) => !p.hold).map((p) => { const b = h("button", { type: "button", class: "chipbtn", disabled: !full || !canAssign, "aria-pressed": String(d.assignees.includes(p.id)), onclick: () => { d.assignees = d.assignees.includes(p.id) ? d.assignees.filter((x) => x !== p.id) : [...d.assignees, p.id]; b.setAttribute("aria-pressed", String(d.assignees.includes(p.id))); } }, avatar(p.name, "sm", p.photo), p.id === me ? "Me" : p.name); return b; }));
    const dlg = overlay([h("h2", {}, t ? (full ? "Task" : "Your task") : "New task"),
      field("Task", h("input", { type: "text", value: d.title, disabled: !full, placeholder: "What needs doing?", oninput: (e) => { d.title = e.target.value; } })),
      field("Details", h("textarea", { rows: 3, disabled: !full, oninput: (e) => { d.details = e.target.value; } }, d.details)),
      h("div", { class: "grid g3" }, field("Due", h("input", { type: "date", value: d.due, disabled: !full, oninput: (e) => { d.due = e.target.value; } })), field("Priority", h("select", { disabled: !full, onchange: (e) => { d.priority = e.target.value; } }, Object.entries(PRI).map(([k, l]) => h("option", { value: k, selected: d.priority === k }, l)))), field("Status", h("select", { onchange: (e) => { d.status = e.target.value; } }, COLS.map(([k, l]) => h("option", { value: k, selected: d.status === k }, l))))),
      ventures.length ? field("Project (optional)", h("select", { disabled: !full, onchange: (e) => { d.project = e.target.value; } }, [h("option", { value: "" }, "—"), ...ventures.map((v) => h("option", { value: v.id, selected: d.project === v.id }, v.name))])) : null,
      h("div", { class: "field" }, h("label", {}, canAssign ? "Assigned to" : "Assigned to"), people, !canAssign && h("div", { class: "hint" }, "Your designation can save tasks for yourself. Project Managers and the super account can assign to others.")),
      h("div", { class: "foot" }, t && full && h("button", { class: "btn danger", style: "margin-right:auto", onclick: run(async () => { if (!(await confirmBox("Delete this task?", "", "Delete", true))) return; await api("DELETE", "/tasks/" + t.id); dlg.close(); toast("Deleted"); reload(); }) }, "Delete"), h("button", { class: "btn ghost", onclick: () => dlg.close() }, "Cancel"),
        h("button", { class: "btn", onclick: run(async () => { if (t) await api("PATCH", "/tasks/" + t.id, d); else await api("POST", "/tasks", d); dlg.close(); toast(t ? "Saved ✓" : d.assignees.some((a) => a !== me) ? "Saved — assignees notified ✓" : "Saved ✓"); reload(); }) }, t ? "Save" : "Save task"))], { wide: true });
  }
  const edit = (t) => form(t);
  main.append(pageHead("Tasks", "Your task list. Assigned people get a notice."), h("div", { class: "toolbar" }, segmented([["mine", "For me"], ["by", "Assigned by me"], ...(isSuper ? [["all", "Everyone"]] : [])], scope, (v) => { scope = v; draw(); }), h("div", { class: "grow" }), h("button", { class: "btn", onclick: () => form(null) }, icon("plus", "sm"), "New task")), box); draw();
}
