/* Documentation → Manuals (written by the super account, read by everyone) and Notes (yours, optionally shared). */
import { h, state, api, run, icon, toast, ago, pageHead, empty, field, confirmBox } from "/ui.js";

export const manuals = (main, args) => view(main, args, "manual");
export const notes = (main, args) => view(main, args, "note");

async function view(main, args, kind) {
  const isManual = kind === "manual"; let items = await api("GET", "/pages?kind=" + kind), cur = args[0] || items[0]?.id || null, editing = false;
  const toc = h("div", { class: "toc" }), doc = h("div");
  const canCreate = !isManual || state.boot.isSuper;
  const draw = () => {
    toc.replaceChildren(...items.map((p) => h("button", { class: "nav", "aria-current": String(p.id === cur), onclick: () => { cur = p.id; editing = false; history.replaceState(null, "", `#/${kind}s/${p.id}`); draw(); } }, icon(isManual ? "book" : "note"), h("span", {}, p.title))));
    const p = items.find((x) => x.id === cur);
    if (!p) return doc.replaceChildren(empty(isManual ? "No manuals yet" : "No notes yet", canCreate ? "Start with the New button." : ""));
    if (editing && p.canEdit) {
      const d = { title: p.title, body: p.body, shared: p.shared };
      return doc.replaceChildren(h("div", { class: "card" }, field("Title", h("input", { type: "text", value: d.title, oninput: (e) => { d.title = e.target.value; } })), field("Text", h("textarea", { rows: 16, oninput: (e) => { d.body = e.target.value; } }, d.body)),
        !isManual && h("label", { class: "check", style: "margin:12px 0" }, h("input", { type: "checkbox", checked: d.shared, onchange: (e) => { d.shared = e.target.checked; } }), "Share with everyone in the Console"),
        h("div", { class: "row" }, h("button", { class: "btn", onclick: run(async () => { const r = await api("PATCH", "/pages/" + p.id, d); Object.assign(p, r); editing = false; toast("Saved ✓"); draw(); }) }, "Save"), h("button", { class: "btn ghost", onclick: () => { editing = false; draw(); } }, "Cancel"),
          h("button", { class: "btn danger", style: "margin-left:auto", onclick: run(async () => { if (!(await confirmBox(`Delete “${p.title}”?`, "", "Delete", true))) return; await api("DELETE", "/pages/" + p.id); items = items.filter((x) => x.id !== p.id); cur = items[0]?.id || null; editing = false; toast("Deleted"); draw(); }) }, "Delete"))));
    }
    doc.replaceChildren(h("article", {}, h("h2", {}, p.title), document.createTextNode(p.body)), h("div", { class: "row tiny muted", style: "margin-top:10px" }, `Updated ${ago(p.updatedAt)} by ${p.updatedBy}`, !isManual && p.shared && h("span", { class: "pill" }, p.mine ? "Shared" : "Shared by " + (p.ownerName || "a colleague")), p.canEdit && h("button", { class: "btn ghost sm", style: "margin-left:auto", onclick: () => { editing = true; draw(); } }, icon("edit", "sm"), "Edit")));
  };
  const create = run(async () => { const p = await api("POST", "/pages", { kind, title: isManual ? "New manual" : "New note", body: "" }); p.mine = true; p.canEdit = true; items.unshift(p); cur = p.id; editing = true; draw(); });
  main.append(pageHead(isManual ? "Manuals" : "Notes", isManual ? "How the Console and the company work." : "Your own notes. Private unless you share them."), canCreate ? h("div", { class: "toolbar" }, h("div", { class: "grow" }), h("button", { class: "btn", onclick: create }, icon("plus", "sm"), isManual ? "New manual" : "New note")) : h("span"), h("div", { class: "manual" }, toc, doc)); draw();
}
