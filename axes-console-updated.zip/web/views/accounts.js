/* Accounts: the super account creates them directly; a Project Manager proposes them (the super account authenticates). */
import { can, h, state, api, run, icon, toast, ago, fmtDate, avatar, pageHead, empty, field, overlay, drawer, confirmBox, copy } from "/ui.js";
import { limitText } from "/views/approvals.js";

const DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
export function limitsEditor(l) {
  const d = { validFrom: "", validUntil: "", days: [], from: "", to: "", tz: 360, maxSessionHours: 0, ...l, days: [...(l?.days || [])] };
  const inp = (k, type, extra = {}) => h("input", { type, value: d[k] || "", ...extra, oninput: (e) => { d[k] = type === "number" ? Number(e.target.value) : e.target.value; } });
  const days = h("div", { class: "limit-days" }, DAYS.map((n, i) => { const b = h("button", { type: "button", class: "chipbtn", "aria-pressed": String(d.days.includes(i)), onclick: () => { d.days = d.days.includes(i) ? d.days.filter((x) => x !== i) : [...d.days, i]; b.setAttribute("aria-pressed", String(d.days.includes(i))); } }, n); return b; }));
  return { value: () => d, el: h("div", {}, h("div", { class: "grid g2" }, field("Access starts", inp("validFrom", "date")), field("Access ends", inp("validUntil", "date"))),
    field("Allowed days", days, "Leave all off for every day."), h("div", { class: "grid g3" }, field("From (time)", inp("from", "time")), field("Until (time)", inp("to", "time")), field("Max session (hours)", inp("maxSessionHours", "number", { min: 0, max: 168 }), "0 = default (12 h)")),
    h("div", { class: "hint" }, "Times follow Bangladesh time (UTC+6).")) };
}
const desigSelect = (value, onchange) => h("select", { onchange: (e) => onchange(e.target.value) }, state.boot.designations.filter((d) => d.id !== "super").map((d) => h("option", { value: d.id, selected: d.id === value }, d.label)));

function createDialog(done) {
  const isSuper = state.boot.isSuper, canSalary = isSuper || can("salary.manage"), d = { name: "", username: "", email: "", skills: "", conditions: "", salary: "", designation: state.boot.designations.find((x) => x.id !== "super").id }, lim = limitsEditor();
  const bind = (k, type = "text", extra = {}) => h("input", { type, ...extra, oninput: (e) => { d[k] = e.target.value; } });
  const dlg = overlay([h("h2", {}, isSuper ? "New account" : "Propose an account"), !isSuper && h("div", { class: "banner" }, icon("stamp", "sm"), h("span", { class: "grow" }, "The super account must authenticate it before the account exists.")),
    h("div", { class: "grid g2" }, field("Full name", bind("name")), field("Username (ID)", bind("username", "text", { autocapitalize: "none", placeholder: "e.g. rafi" }))),
    h("div", { class: "grid g2" }, field("E-mail", bind("email", "email"), "Used for the invitation and notices."), field("Designation", desigSelect(d.designation, (v) => { d.designation = v; }))),
    h("div", { class: "grid g2" }, field("Skills", bind("skills", "text", { placeholder: "e.g. accounting, design, site supervision" }), "Comma separated. Used to choose teams quickly."), canSalary && field("Monthly salary (" + state.boot.currency + ")", bind("salary", "number", { min: 0 }))),
    field("Conditions of employment", h("textarea", { rows: 2, placeholder: "Contract type, working conditions, notes…", oninput: (e) => { d.conditions = e.target.value; } })),
    h("details", { class: "item" }, h("summary", {}, h("span", { class: "title" }, "Limitations"), h("span", { class: "muted small" }, "when this account may work")), h("div", { class: "body" }, lim.el)),
    h("p", { class: "muted small" }, "The person chooses their own password from a private link — nobody else ever sees it."),
    h("div", { class: "foot" }, h("button", { class: "btn ghost", onclick: () => dlg.close() }, "Cancel"), h("button", { class: "btn", onclick: run(async () => {
      const r = await api("POST", "/accounts", { ...d, skills: d.skills, salary: { amount: Number(d.salary) || 0 }, limits: lim.value() }); dlg.close();
      if (r.pending) toast("Sent to the super account for authentication ✓"); else { done(); const box = h("input", { type: "text", readonly: true, value: r.inviteUrl, onfocus: (e) => e.target.select() }); const x = overlay([h("h2", {}, "Account created"), h("p", {}, `Give ${r.username} this private link so they can choose a password (valid 3 days).` + (r.emailed ? " It was also e-mailed." : "")), h("div", { class: "row" }, box, h("button", { class: "btn", onclick: () => copy(r.inviteUrl, "Link copied") }, "Copy")), h("div", { class: "foot" }, h("button", { class: "btn", onclick: () => x.close() }, "Done"))]); return; }
      done(); }) }, isSuper ? "Create account" : "Send for authentication"))], { wide: true });
}

export default async function (main) {
  const isSuper = state.boot.isSuper; let list = await api("GET", "/accounts"), q = "", ctl = null;
  const box = h("div");
  const reload = async () => { list = await api("GET", "/accounts"); draw(); };
  const draw = () => {
    const rows = list.filter((u) => !q || (u.name + u.username + u.designationLabel + (u.skills || []).join(" ")).toLowerCase().includes(q));
    box.replaceChildren(h("div", { class: "grid auto" }, rows.map((u) => h("button", { class: "kpi", style: "align-items:flex-start;text-align:left;gap:10px", onclick: () => show(u) },
      h("div", { class: "row", style: "width:100%" }, avatar(u.name, "lg", u.photo), h("div", { class: "grow", style: "min-width:0" }, h("b", { style: "display:block;font-size:16px" }, u.name), h("span", { class: "muted small" }, "@" + u.username))),
      h("div", { class: "row wrap" }, h("span", { class: "pill " + (u.kind === "super" ? "role-super" : "") }, u.designationLabel), u.hold && h("span", { class: "pill bad" }, "On hold"), u.pending && h("span", { class: "pill warn" }, "Invite pending"), u.blocked && !u.hold && h("span", { class: "pill warn" }, "Outside allowed time")),
      (u.skills?.length ? h("div", { class: "skills" }, u.skills.slice(0, 6).map((x) => h("span", { class: "pill info" }, x))) : null),
      h("div", { class: "tiny muted" }, u.kind === "super" ? "Founder · no limits, cannot be held or removed" : limitText(u.limits))))));
  };
  function show(u) {
    ctl?.close(); const title = h("div"), body = h("div", { class: "db" }); ctl = drawer(title, body, { onClose: () => (ctl = null) });
    const sup = u.kind === "super", lim = limitsEditor(u.limits), d = { name: u.name, email: u.email, designation: u.designation, skills: (u.skills || []).join(", "), conditions: u.conditions || "" };
    title.append(h("div", { class: "row" }, avatar(u.name, "lg", u.photo), h("div", {}, h("h2", {}, u.name), h("span", { class: "muted small" }, `@${u.username} · ${u.designationLabel}`))));
    body.append(
      h("dl", { class: "kv" }, [["Created", fmtDate(u.createdAt) + (u.createdByName ? " by " + u.createdByName : "")], ["Last sign-in", u.lastLogin ? ago(u.lastLogin) : "Never"], ["Storage", `${(u.usage.used / 1048576).toFixed(1)} MB · ${u.usage.files} files`]].flatMap(([k, v]) => [h("dt", {}, k), h("dd", {}, v)])),
      sup ? h("div", { class: "banner", style: "margin-top:16px" }, icon("shield", "sm"), h("span", { class: "grow" }, "The super account has every power. It cannot be held, limited, demoted or deleted by anyone.")) : [
        h("div", { class: "sect" }, h("h3", {}, "Details"), h("div", { class: "grid g2" }, field("Name", h("input", { type: "text", value: d.name, oninput: (e) => { d.name = e.target.value; } })), field("E-mail", h("input", { type: "email", value: d.email, oninput: (e) => { d.email = e.target.value; } }))), field("Designation", desigSelect(d.designation, (v) => { d.designation = v; })), field("Skills", h("input", { type: "text", value: d.skills, placeholder: "comma separated", oninput: (e) => { d.skills = e.target.value; } })), field("Conditions of employment", h("textarea", { rows: 2, oninput: (e) => { d.conditions = e.target.value; } }, d.conditions)), u.salary && h("p", { class: "small" }, `Monthly salary: ${u.salary.amount ? u.salary.amount.toLocaleString() + " " + state.boot.currency : "not set"} · change it under Salary.`)),
        h("div", { class: "sect" }, h("h3", {}, "Limitations"), lim.el),
        !isSuper && h("div", { class: "banner" }, icon("stamp", "sm"), h("span", { class: "grow" }, "Changes are sent to the super account for authentication.")),
        h("div", { class: "row wrap sect" }, h("button", { class: "btn", onclick: run(async () => { const r = await api("PATCH", "/accounts/" + u.id, { ...d, limits: lim.value() }); toast(r.pending ? "Sent to the super account for authentication ✓" : "Saved ✓"); await reload(); if (!r.pending) ctl.close(); }) }, isSuper ? "Save" : "Send for authentication")),
        isSuper && h("div", { class: "sect" }, h("h3", {}, "Super account actions"), h("div", { class: "row wrap" },
          h("button", { class: "btn ghost", onclick: run(async () => { await api("PATCH", "/accounts/" + u.id, { hold: !u.hold }); toast(u.hold ? "Resumed" : "Put on hold"); ctl.close(); reload(); }) }, u.hold ? "Resume account" : "Put on hold"),
          h("button", { class: "btn ghost", onclick: run(async () => { const r = await api("POST", `/accounts/${u.id}/invite`); const x = overlay([h("h2", {}, "New password link"), h("p", {}, `${u.name} can choose a new password here (valid 3 days).` + (r.emailed ? " It was also e-mailed." : "")), h("div", { class: "row" }, h("input", { type: "text", readonly: true, value: r.inviteUrl, onfocus: (e) => e.target.select() }), h("button", { class: "btn", onclick: () => copy(r.inviteUrl, "Link copied") }, "Copy")), h("div", { class: "foot" }, h("button", { class: "btn", onclick: () => x.close() }, "Done"))]); }) }, "New password link"),
          h("button", { class: "btn ghost", onclick: run(async () => { await api("POST", `/accounts/${u.id}/signout`); toast("Signed out everywhere"); }) }, "Sign out everywhere"),
          h("button", { class: "btn danger", onclick: run(async () => { if (!(await confirmBox(`Delete ${u.name}?`, "Their private vault, notes and assignments are removed. This cannot be undone. Consider putting the account on hold instead.", "Delete", true))) return; await api("DELETE", "/accounts/" + u.id); toast("Deleted"); ctl.close(); reload(); }) }, "Delete")))]);
  }
  main.append(pageHead("Accounts & skills", isSuper ? "Create accounts, set designations and limitations, hold or remove. Search by skill to pick a team." : "Every account with its skills and conditions. Human Resources proposes changes; the super account authenticates them."), h("div", { class: "toolbar" }, h("input", { class: "search", type: "search", placeholder: "Search people or skills", "aria-label": "Search", oninput: (e) => { q = e.target.value.trim().toLowerCase(); draw(); } }), h("div", { class: "grow" }), (isSuper || can("accounts.propose")) && h("button", { class: "btn", onclick: () => createDialog(reload) }, icon("plus", "sm"), isSuper ? "New account" : "Propose account")), box);
  draw(); return () => ctl?.close();
}
