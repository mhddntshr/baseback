/* Business → Salary. Everyone sees their own salary and what was paid. Human Resources and the super account see everyone's. */
import { h, state, api, run, icon, toast, fmtDate, avatar, pageHead, empty, field, overlay, confirmBox } from "/ui.js";

const money = (n) => `${Math.round(n || 0).toLocaleString()} ${state.boot.currency}`;
const monthName = (p) => new Date(p + "-01T00:00:00Z").toLocaleString([], { month: "long", year: "numeric", timeZone: "UTC" });
const sent = (r) => toast(r.pending ? "Sent to the super account for authentication ✓" : "Saved ✓");

export default async function (main) {
  let data = await api("GET", "/salary"); const box = h("div"), boss = state.boot.isSuper;
  const reload = async () => { data = await api("GET", "/salary"); draw(); };
  const termsDialog = (p) => {
    const amt = h("input", { type: "number", min: 0, value: p.terms.amount || "" }), note = h("input", { type: "text", value: p.terms.note || "", placeholder: "e.g. includes transport" });
    const d = overlay([h("h2", {}, `Salary · ${p.name}`), !boss && h("div", { class: "banner" }, icon("stamp", "sm"), h("span", { class: "grow" }, "Sent to the super account. It changes only once authenticated.")), field("Monthly salary (" + state.boot.currency + ")", amt), field("Note", note),
      h("div", { class: "foot" }, h("button", { class: "btn ghost", onclick: () => d.close() }, "Cancel"), h("button", { class: "btn", onclick: run(async () => { const r = await api("POST", "/salary/terms", { userId: p.id, amount: Number(amt.value) || 0, note: note.value }); d.close(); sent(r); reload(); }) }, boss ? "Save" : "Send for authentication"))]);
  };
  const payDialog = (p) => {
    const period = h("input", { type: "month", value: data.now }), amt = h("input", { type: "number", min: 0, value: p.terms.amount || "" }), note = h("input", { type: "text", placeholder: "Optional" });
    const d = overlay([h("h2", {}, `Record salary paid · ${p.name}`), !boss && h("div", { class: "banner" }, icon("stamp", "sm"), h("span", { class: "grow" }, "Sent to the super account for authentication.")), h("div", { class: "grid g2" }, field("For month", period), field("Amount (" + state.boot.currency + ")", amt)), field("Note", note),
      h("div", { class: "foot" }, h("button", { class: "btn ghost", onclick: () => d.close() }, "Cancel"), h("button", { class: "btn", onclick: run(async () => { const r = await api("POST", "/salary/pay", { userId: p.id, period: period.value, amount: Number(amt.value) || 0, note: note.value }); d.close(); sent(r); reload(); }) }, boss ? "Record" : "Send for authentication"))]);
  };
  const history = (pays, removable) => pays.length ? h("div", { class: "list" }, pays.map((x) => h("div", { class: "li" }, h("span", { class: "grow" }, h("b", {}, monthName(x.period)), h("span", { class: "muted small" }, ` ${x.note || ""}`)), h("b", {}, money(x.amount)), h("span", { class: "muted tiny" }, fmtDate(x.paidAt)),
    removable && h("button", { class: "ico-btn", "aria-label": "Remove payment", onclick: run(async () => { if (!(await confirmBox("Remove this payment record?", "", "Remove", true))) return; await api("DELETE", "/salary/pay/" + x.id); reload(); }) }, icon("x", "sm"))))) : h("p", { class: "muted small" }, "No payments recorded yet.");
  function draw() {
    const m = data.me;
    box.replaceChildren(
      boss && !data.everyone?.length ? null : null,
      !boss && h("div", { class: "card" }, h("h3", {}, "My salary"), h("div", { class: "sal-me", style: "margin:10px 0 16px" }, h("div", {}, h("div", { class: "n" }, m.terms.amount ? money(m.terms.amount) : "Not set"), h("div", { class: "muted small" }, "per month" + (m.terms.note ? " · " + m.terms.note : "")))), history(m.payments, false)),
      data.canManage && h("div", { style: "margin-top:20px" }, h("h3", { style: "margin-bottom:10px" }, "Everyone"), data.everyone.length ? h("div", { class: "list" }, data.everyone.map((p) => h("details", { class: "item" }, h("summary", {}, avatar(p.name, "sm", p.photo), h("span", { class: "grow" }, h("b", { class: "title" }, p.name), h("span", { class: "muted small", style: "display:block" }, p.designation)), h("span", { class: "small" }, p.terms.amount ? money(p.terms.amount) : "no salary set"), h("span", { class: "pill " + (p.paidThisMonth ? "ok" : "warn") }, p.paidThisMonth ? "Paid " + monthName(data.now).split(" ")[0] : "Not paid yet")),
        h("div", { class: "body" }, h("div", { class: "row wrap", style: "margin-bottom:12px" }, h("button", { class: "btn sm", onclick: () => payDialog(p) }, icon("plus", "sm"), "Record payment"), h("button", { class: "btn ghost sm", onclick: () => termsDialog(p) }, icon("edit", "sm"), "Set salary")), history(p.payments, boss))))) : empty("No other accounts yet", "Accounts appear here once they exist.")),
      !data.canManage && boss && null);
  }
  main.append(pageHead("Salary", boss ? "Everyone's salary and payments. You can record payments directly." : data.canManage ? "Everyone's salary. Changes and payments you record are authenticated by the super account." : "Your monthly salary and what has been paid."), box); draw();
}
