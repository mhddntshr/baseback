import { h, state, api, run, icon, toast, fmtDate, ago, fmtSize, fmtMB, meter, pageHead, empty, field, touch, clone, avatar, segmented, $ } from "/ui.js";

const saveBar = (onSave, onDiscard) => h("div", { class: "savebar" }, h("span", { class: "msg" }, "No changes"), h("button", { class: "btn ghost discard", disabled: true, onclick: onDiscard }, "Discard"), h("button", { class: "btn save", disabled: true, onclick: run(onSave) }, "Save"));
const ok = (msg) => { state.dirty = false; toast(msg); };

/* ---------- e-mail ---------- */
export async function email(main) {
  const s = await api("GET", "/email"), log = await api("GET", "/email/log"), d = clone(s);
  const bind = (obj, k, type = "text", extra = {}) => h("input", { type, value: obj[k] ?? "", ...extra, oninput: (e) => { obj[k] = type === "number" ? Number(e.target.value) : e.target.value; touch(); } });
  const sw = (label, obj, k, dis) => h("label", { class: "check" }, h("input", { type: "checkbox", checked: !!obj[k], disabled: dis, onchange: (e) => { obj[k] = e.target.checked; touch(); } }), label);
  const pass = h("input", { type: "password", placeholder: s.smtp.passSet ? "•••••••• (saved)" : "Password", autocomplete: "new-password", oninput: (e) => { d.smtp.pass = e.target.value; touch(); } });
  const test = h("input", { type: "email", placeholder: "Send a test to…" });
  const tpl = h("div");
  s.defs.forEach((def) => { const t = d.templates[def.id]; tpl.append(h("details", { class: "item" }, h("summary", {}, h("span", { class: "title" }, def.label), h("span", { class: "pill" }, def.to)), h("div", { class: "body" }, field("Subject", bind(t, "subject")), h("div", { class: "field" }, h("label", {}, "Message"), h("textarea", { rows: 7, value: t.body, oninput: (e) => { t.body = e.target.value; touch(); } }), h("div", { class: "hint" }, "Fields: " + def.vars.split(" ").map((v) => `{${v}}`).join(" ")))))); });
  const st = (x) => x === "sent" ? "st-sent" : x === "failed" ? "st-failed" : "st-not";
  main.append(pageHead("E-mail setup", s.configured ? "SMTP connected" : "Not connected — messages are kept in the log below"),
    h("div", { class: "card", style: "margin-bottom:14px" }, h("h2", {}, "Server"), s.lockedByEnv && h("p", { class: "muted small" }, "Set by environment variables on your host."),
      h("div", { class: "grid g2" }, field("Host", bind(d.smtp, "host", "text", { disabled: s.lockedByEnv, placeholder: "smtp.gmail.com" })), field("Port", bind(d.smtp, "port", "number", { disabled: s.lockedByEnv }))),
      h("div", { class: "grid g2" }, field("User", bind(d.smtp, "user", "text", { disabled: s.lockedByEnv })), field("Password", pass)), sw("Secure connection (port 465)", d.smtp, "secure", s.lockedByEnv)),
    h("div", { class: "card", style: "margin-bottom:14px" }, h("h2", {}, "Sender"), h("div", { class: "grid g2" }, field("Name", bind(d, "fromName")), field("From address", bind(d, "from", "email", { placeholder: "hello@yourdomain.com" }))),
      field("Console address", bind(d, "siteUrl", "url", { placeholder: "https://console.example.com" }), "Used in the links inside e-mails (invitations).")),
    h("div", { class: "card", style: "margin-bottom:14px" }, h("h2", {}, "Test"), h("div", { class: "row" }, test, h("button", { class: "btn", onclick: run(async () => { const r = await api("POST", "/email/test", { to: test.value }); toast(r.status === "sent" ? "Sent ✓" : r.note || r.status, r.status === "failed"); }) }, "Send"))),
    h("div", { class: "sect" }, h("h3", {}, "Automatic messages"), tpl),
    h("div", { class: "sect" }, h("h3", {}, "Log"), log.length ? h("div", { class: "list" }, log.slice(0, 40).map((m) => h("details", { class: "item" }, h("summary", {}, h("span", { class: "title" }, m.subject), h("span", { class: "pill " + st(m.status) }, m.status), h("span", { class: "muted tiny nowrap" }, ago(m.t))), h("div", { class: "body" }, h("p", { class: "muted small" }, "To " + m.to + (m.note ? " · " + m.note : "")), h("pre", { style: "white-space:pre-wrap;font:inherit;font-size:13px" }, m.text))))) : empty("Nothing sent yet", "")),
    saveBar(async () => { const r = await api("PUT", "/email", d); ok("Saved"); email(main.replaceChildren() || main); }, () => { state.dirty = false; main.replaceChildren(); email(main); }));
}

/* ---------- storage plans ---------- */
export async function storage(main) {
  const data = await api("GET", "/plans"), usage = await api("GET", "/vault-usage"), d = clone(data);
  const box = h("div", { class: "grid auto" });
  const num = (o, k, min = 1) => h("input", { type: "number", min, value: o[k], oninput: (e) => { o[k] = Number(e.target.value); touch(); } });
  const draw = () => box.replaceChildren(...d.plans.map((p, i) => h("div", { class: "plan-card" }, h("div", { class: "row", style: "margin-bottom:12px" }, h("input", { type: "text", value: p.name, "aria-label": "Plan name", style: "font-weight:600", oninput: (e) => { p.name = e.target.value; touch(); } }), d.plans.length > 1 && h("button", { class: "ico-btn", "aria-label": "Remove plan", onclick: () => { d.plans.splice(i, 1); touch(); draw(); } }, icon("x", "sm"))),
    field("Storage (MB)", num(p, "quotaMB", 10)), field("Largest file (MB)", num(p, "maxFileMB")), h("div", { class: "grid g2" }, field("Versions kept", num(p, "versions")), field("Trash days", num(p, "trashDays", 0))), h("label", { class: "check" }, h("input", { type: "checkbox", checked: p.sharing, onchange: (e) => { p.sharing = e.target.checked; touch(); } }), "Share links"))));
  draw();
  const def = (role, label) => field(label, h("select", { onchange: (e) => { d.defaults[role] = e.target.value; touch(); } }, d.plans.map((p) => h("option", { value: p.id, selected: d.defaults[role] === p.id }, p.name))));
  main.append(pageHead("Storage plans", "Every account has a private, encrypted vault.", h("button", { class: "btn ghost", onclick: () => { d.plans.push({ id: "plan" + Date.now().toString(36), name: "New plan", quotaMB: 500, maxFileMB: 50, versions: 5, trashDays: 30, sharing: true }); touch(); draw(); } }, icon("plus", "sm"), "Plan")),
    box, h("div", { class: "sect", style: "margin-top:20px" }, h("h3", {}, "Default for new accounts"), h("div", { class: "grid g3" }, def("super", "Super account"), def("project_manager", "Project managers"), def("member", "Everyone else"))),
    h("div", { class: "sect" }, h("h3", {}, "Usage"), h("div", { class: "list" }, usage.map((u) => h("div", { class: "li" }, avatar(u.name, "sm"), h("div", { class: "grow" }, h("b", {}, u.name), h("span", { class: "muted small" }, `${u.designation} · ${u.planName}`)), h("div", { style: "width:160px" }, meter(u.used, u.quotaMB * 1048576), h("span", { class: "muted tiny" }, `${fmtSize(u.used)} / ${fmtMB(u.quotaMB)}`)))))),
    saveBar(async () => { await api("PUT", "/plans", d); ok("Saved"); main.replaceChildren(); storage(main); }, () => { state.dirty = false; main.replaceChildren(); storage(main); }));
}

/* ---------- activity ---------- */
export async function activity(main) {
  const list = await api("GET", "/audit");
  main.append(pageHead("Activity", state.boot.isSuper ? "Everything done in the Console, newest first." : "Your own activity."), list.length ? h("div", { class: "list" }, list.map((a) => h("div", { class: "li" }, avatar(a.who, "sm"), h("span", { class: "grow" }, h("b", {}, a.who), h("span", { class: "muted small" }, `${a.action}${a.target ? " · " + a.target : ""}`)), h("span", { class: "muted tiny nowrap", title: fmtDate(a.t) }, ago(a.t))))) : empty("Nothing yet", ""));
}
