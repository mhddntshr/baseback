/* Ongoing → Support inbox: messages come in, replies go out by e-mail. */
import { h, state, api, run, icon, toast, ago, fmtDate, pageHead, empty, field, overlay, drawer, statusPill, personName } from "/ui.js";
import { refresh } from "/shell.js";

export default async function (main, args) {
  let data = await api("GET", "/support"), filter = "active", who = "", ctl = null; const box = h("div");
  const reload = async () => { data = await api("GET", "/support"); await refresh(); draw(); };
  const rows = () => data.items.filter((t) => (filter === "active" ? t.status !== "closed" : filter === "all" || t.status === filter) && (!who || t.audience === who));
  const audLabel = (id) => data.audiences.find((a) => a.id === id)?.label || "Other";
  const stLabel = (id) => data.statuses.find((s) => s.id === id)?.label || id;
  function draw() {
    const l = rows();
    box.replaceChildren(l.length ? h("div", { class: "list" }, l.map((t) => h("button", { class: "li", style: "width:100%;text-align:left", onclick: () => show(t.id) }, h("span", { class: "grow", style: "min-width:0" }, h("b", { class: t.status === "new" ? "" : "", style: "display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" }, t.subject), h("span", { class: "muted small", style: "display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" }, `${t.name} · ${t.last}`)), t.assignee && h("span", { class: "tiny muted" }, personName(t.assignee)), h("span", { class: "pill info" }, audLabel(t.audience)), h("span", { class: "pill st-" + t.status }, stLabel(t.status)), h("span", { class: "muted tiny nowrap" }, ago(t.updatedAt))))) : empty("Inbox is clear", "New messages appear here. Log one by hand with “New message”."));
  }
  async function show(id) {
    ctl?.close(); const title = h("div"), body = h("div", { class: "db" }); ctl = drawer(title, body, { onClose: () => (ctl = null) });
    const render = async (t) => {
      t ||= await api("GET", "/support/" + id);
      title.replaceChildren(h("h2", {}, t.subject), h("div", { class: "muted small" }, `${audLabel(t.audience)} · ${t.name}${t.email ? " <" + t.email + ">" : ""} · ${t.ref}`));
      const reply = h("textarea", { rows: 5, placeholder: t.email ? `Reply to ${t.name} by e-mail…` : `Reply to ${t.name} in the Console…` }), close = h("input", { type: "checkbox" });
      body.replaceChildren(
        h("div", { class: "row wrap" }, h("select", { "aria-label": "Status", onchange: run(async (e) => { await api("PATCH", "/support/" + id, { status: e.target.value }); await reload(); render(); }) }, data.statuses.map((s) => h("option", { value: s.id, selected: s.id === t.status }, s.label))),
          h("select", { "aria-label": "Assigned to", onchange: run(async (e) => { await api("PATCH", "/support/" + id, { assignee: e.target.value }); await reload(); render(); }) }, [h("option", { value: "" }, "Unassigned"), ...[state.me].map((p) => h("option", { value: p.id, selected: p.id === t.assignee }, "Me (" + p.name + ")")), ...(t.assignee && t.assignee !== state.me.id ? [h("option", { value: t.assignee, selected: true }, personName(t.assignee) || "Someone else")] : [])])),
        h("div", { class: "thread", style: "margin-top:16px" }, t.thread.map((m) => h("div", { class: "msg " + m.dir }, h("small", {}, `${m.dir === "out" ? "Sent by " : m.dir === "note" ? "Internal note · " : ""}${m.byName} · ${fmtDate(m.t)}${m.mail && m.mail !== "sent" ? " · e-mail " + m.mail : ""}`), m.text))),
        h("div", { class: "sect" }, field("Reply", reply), h("label", { class: "check", style: "margin:8px 0" }, close, "Close the message after sending"),
          h("div", { class: "row wrap" }, h("button", { class: "btn", onclick: run(async () => { const r = await api("POST", `/support/${id}/reply`, { text: reply.value, close: close.checked }); toast(r.mail === "sent" ? "E-mail sent ✓" : r.note || "E-mail " + r.mail, r.mail === "failed"); await reload(); render(r.ticket); }) }, icon("send", "sm"), "Send reply"),
            h("button", { class: "btn ghost", onclick: run(async () => { const r = await api("POST", `/support/${id}/note`, { text: reply.value }); toast("Note saved"); render(r); }) }, "Save as internal note"), state.boot.isSuper && h("button", { class: "btn danger", style: "margin-left:auto", onclick: run(async () => { await api("DELETE", "/support/" + id); ctl.close(); toast("Deleted"); reload(); }) }, "Delete"))),
        !state.boot.emailConfigured && h("p", { class: "muted small" }, "E-mail is not connected yet: replies are kept in the e-mail log until the super account sets up SMTP (Ongoing → E-mail setup)."));
    };
    try { await render(); } catch (e) { ctl?.close(); toast(e.message, true); }
  }
  function log() {
    const d = { name: "", email: "", subject: "", message: "", audience: "customer" }, b = (k, t = "text") => h("input", { type: t, oninput: (e) => { d[k] = e.target.value; } });
    const dlg = overlay([h("h2", {}, "New message"), h("p", { class: "muted small" }, "Log a message that reached the support mailbox so the team can answer it here."), h("div", { class: "grid g2" }, field("From name", b("name")), field("From e-mail", b("email", "email"))), field("Who is it from?", h("select", { onchange: (e) => { d.audience = e.target.value; } }, data.audiences.filter((a) => a.id !== "employee").map((a) => h("option", { value: a.id }, a.label)))), field("Subject", b("subject")), field("Message", h("textarea", { rows: 6, oninput: (e) => { d.message = e.target.value; } })),
      h("div", { class: "foot" }, h("button", { class: "btn ghost", onclick: () => dlg.close() }, "Cancel"), h("button", { class: "btn", onclick: run(async () => { const t = await api("POST", "/support", d); dlg.close(); await reload(); show(t.id); }) }, "Save"))], { wide: true });
  }
  main.append(pageHead("Support inbox", "The company’s main support desk: employees, clients and customers all write here."), h("div", { class: "toolbar" }, h("select", { "aria-label": "From", onchange: (e) => { who = e.target.value; draw(); } }, [["", "Everyone"], ...data.audiences.map((a) => [a.id, a.label + "s"])].map(([v, l]) => h("option", { value: v }, l))), h("select", { "aria-label": "Show", onchange: (e) => { filter = e.target.value; draw(); } }, [["active", "Open messages"], ["all", "Everything"], ...data.statuses.map((s) => [s.id, s.label])].map(([v, l]) => h("option", { value: v }, l))), h("div", { class: "grow" }), h("button", { class: "btn", onclick: log }, icon("plus", "sm"), "New message")), box);
  draw(); if (args[0]) show(args[0]); return () => ctl?.close();
}
