/* Ongoing → Notices: what happened that concerns you. */
import { h, state, api, run, ago, pageHead, empty, icon } from "/ui.js";
import { refresh, go } from "/shell.js";

export default async function (main) {
  let list = await api("GET", "/notices"); const box = h("div");
  const draw = () => box.replaceChildren(list.length ? h("div", {}, list.map((n) => h("button", { class: "notice" + (n.read ? "" : " unread"), onclick: run(async () => { if (!n.read && !n.virtual) await api("POST", "/notices/read", { ids: [n.id] }); n.read = true; await refresh(); if (n.link) location.hash = n.link; else draw(); }) }, h("span", { class: "grow tx" }, n.text), h("span", { class: "muted tiny nowrap" }, ago(n.t))))) : empty("No notices", "Tasks assigned to you, decisions on your proposals and report reminders show up here."));
  main.append(pageHead("Notices", "Short messages that concern you."), list.some((n) => !n.read && !n.virtual) ? h("div", { class: "toolbar" }, h("div", { class: "grow" }), h("button", { class: "btn ghost sm", onclick: run(async () => { await api("POST", "/notices/read", { all: true }); list = await api("GET", "/notices"); await refresh(); draw(); }) }, icon("check", "sm"), "Mark all read")) : h("span"), box); draw();
}
