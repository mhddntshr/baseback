/* Projects, subsidiaries (with branches and their money), achievements. Business → projects / subsidiaries / achievements, Tracking → tracker, Documentation → archive. */
import { h, state, api, run, icon, toast, can, fmtDate, fmtDay, ago, avatar, whoAvatar, who, pageHead, empty, confirmBox, overlay, drawer, field, segmented, copy } from "/ui.js";

const money = (n) => { const c = state.boot.currency || "BDT"; try { return new Intl.NumberFormat([], { style: "currency", currency: c, maximumFractionDigits: 0 }).format(n || 0); } catch { return c + " " + Math.round(n || 0).toLocaleString(); } };
const stageLabel = (id) => state.boot.stages.find((s) => s.id === id)?.label || id;
const healthLabel = (id) => state.boot.health.find((s) => s.id === id)?.label || id;
const healthCls = { good: "ok", risk: "warn", blocked: "bad" };
export const timelinePill = (v) => { const t = v.timeline || { state: "none" };
  if (t.state === "none") return h("span", { class: "pill" }, "No target date");
  if (t.state === "done") return h("span", { class: "pill ok" }, "Completed");
  if (t.state === "overdue") return h("span", { class: "pill bad" }, `${t.days} day${t.days > 1 ? "s" : ""} overdue`);
  return h("span", { class: "pill " + (t.state === "soon" ? "warn" : "") }, t.days === 0 ? "Due today" : `${t.days} day${t.days > 1 ? "s" : ""} left`); };
const spentBar = (v) => { const pct = v.budget ? Math.min(100, (v.cost / v.budget) * 100) : 0; return h("div", {}, h("div", { class: "pbar" + (v.budget && v.cost > v.budget ? " bad" : pct > 85 ? " warn" : "") }, h("i", { style: `width:${pct}%` })), h("div", { class: "tiny muted", style: "margin-top:4px" }, v.budget ? `${money(v.cost)} of ${money(v.budget)}` : "No budget set")); };
const team = (ids, n = 4) => h("span", { class: "stack-av" }, ids.slice(0, n).map((id) => whoAvatar(id, "sm")), ids.length > n && h("span", { class: "avatar sm" }, "+" + (ids.length - n)), !ids.length && h("span", { class: "tiny muted" }, "No one yet"));
const kindLabel = (v) => ({ subsidiary: "Subsidiary", branch: "Branch" }[v.kind] || "Project");
const personName = (uid) => who(uid)?.name || "Team member";
const ENTRY = [["revenue", "Revenue"], ["cost", "Cost"], ["salary", "Salary"], ["loss", "Loss"], ["withdrawal", "Withdrawal"]];
const entryCls = { revenue: "ok", loss: "bad", withdrawal: "warn" };
const sentMsg = (r) => toast(r.pending ? "Sent to the super account for authentication ✓" : "Saved ✓");

export default (main, args, ctx) => portfolio(main, args, ctx, "manage");
export const tracker = (main, args, ctx) => portfolio(main, args, ctx, "track");
export const archive = (main, args, ctx) => portfolio(main, args, ctx, "archive");
export const subsidiaries = (main, args, ctx) => portfolio(main, args, ctx, "subs");
export const achievements = (main, args, ctx) => portfolio(main, args, ctx, "achievements");

/* ---------- the create / edit form ---------- */
export function projectForm(v, done, opts = {}) {
  const isSuper = state.boot.isSuper, edit = !!v, d = v ? { name: v.name, kind: v.kind, summary: v.summary, budget: v.budget, startDate: v.startDate, targetDate: v.targetDate, milestones: v.milestones.map((m) => ({ ...m })), team: [...v.team], parentId: v.parentId || "" } : { name: "", kind: opts.mode === "subs" ? (state.boot.isSuper ? "subsidiary" : "branch") : "project", parentId: opts.subs?.[0]?.id || "", summary: "", budget: "", startDate: "", targetDate: "", milestones: [], team: [] };
  const inp = (k, type = "text", extra = {}) => h("input", { type, value: d[k] ?? "", ...extra, oninput: (e) => { d[k] = e.target.value; } });
  const ms = h("div"), drawMs = () => ms.replaceChildren(...d.milestones.map((m, i) => h("div", { class: "simple" }, h("input", { type: "text", placeholder: "Milestone", value: m.title, oninput: (e) => { m.title = e.target.value; } }), h("input", { type: "date", value: m.date, style: "max-width:160px", oninput: (e) => { m.date = e.target.value; } }), h("button", { class: "ico-btn", "aria-label": "Remove", onclick: () => { d.milestones.splice(i, 1); drawMs(); } }, icon("x", "sm")))));
  drawMs();
  const people = h("div", { class: "chips" }, state.boot.people.filter((p) => !p.hold).map((p) => { const b = h("button", { type: "button", class: "chipbtn", "aria-pressed": String(d.team.includes(p.id)), onclick: () => { d.team = d.team.includes(p.id) ? d.team.filter((x) => x !== p.id) : [...d.team, p.id]; b.setAttribute("aria-pressed", String(d.team.includes(p.id))); } }, avatar(p.name, "sm", p.photo), p.name, h("small", {}, p.designation)); return b; }));
  const subs = opts.subs || [], parent = h("select", { onchange: (e) => { d.parentId = e.target.value; } }, subs.map((x) => h("option", { value: x.id, selected: d.parentId === x.id }, x.name)));
  const parentField = h("div", { hidden: d.kind !== "branch" }, field("Belongs to subsidiary", parent));
  const kinds = opts.mode === "subs" ? [...(isSuper ? [["subsidiary", "Subsidiary"]] : []), ["branch", "Branch"]] : [["project", "Project"]];
  const kind = h("select", { onchange: (e) => { d.kind = e.target.value; parentField.hidden = d.kind !== "branch"; } }, kinds.map(([k, l]) => h("option", { value: k, selected: d.kind === k }, l)));
  const note = !isSuper ? h("div", { class: "banner" }, icon("stamp", "sm"), h("span", { class: "grow" }, edit ? "This change is sent to the super account. It only takes effect once authenticated." : "Your proposal is sent to the super account. The project is created only once it is authenticated.")) : null;
  const dlg = overlay([h("h2", {}, edit ? "Edit plan" : opts.mode === "subs" ? (isSuper ? "New subsidiary or branch" : "Propose a branch") : isSuper ? "New project" : "Propose a project"), note,
    h("div", { class: "grid g2" }, field("Name", inp("name")), edit ? field("Type", h("input", { type: "text", value: kindLabel(d), disabled: true })) : field("Type", kind)), parentField,
    field("What is it?", h("textarea", { rows: 2, oninput: (e) => { d.summary = e.target.value; } }, d.summary)),
    h("div", { class: "grid g3" }, field("Budget (" + state.boot.currency + ")", inp("budget", "number", { min: 0 })), field("Start", inp("startDate", "date")), field("Target date", inp("targetDate", "date"))),
    h("div", { class: "field" }, h("label", {}, "Timeline milestones"), ms, h("button", { type: "button", class: "btn ghost sm", onclick: () => { d.milestones.push({ title: "", date: "" }); drawMs(); } }, icon("plus", "sm"), "Milestone")),
    h("div", { class: "field" }, h("label", {}, isSuper ? "Assigned people (any number)" : "Suggested team"), people),
    h("div", { class: "foot" }, h("button", { class: "btn ghost", onclick: () => dlg.close() }, "Cancel"), h("button", { class: "btn", onclick: run(async () => {
      const body = { ...d, budget: Number(d.budget) || 0 };
      const r = edit ? (await api("PATCH", "/ventures/" + v.id, Object.fromEntries(["name", "kind", "summary", "budget", "startDate", "targetDate", "milestones", "team"].filter((k) => k !== "kind" && k !== "parentId" || false).map((k) => [k, body[k]])))) : await api("POST", "/ventures", body);
      dlg.close(); sentMsg(r); done?.(r); }) }, edit ? (isSuper ? "Save" : "Send for authentication") : isSuper ? "Create" : "Send for authentication"))], { wide: true });
}

/* ---------- list, board, table ---------- */
async function portfolio(main, args, { go }, mode) {
  const boot = state.boot, archived = mode === "archive", fixedKind = { manage: ["project"], subs: ["subsidiary", "branch"] }[mode];
  let data = await api("GET", "/ventures"), view = mode === "manage" ? "board" : "list", f = { q: "", kind: "", health: "" }, ctl = null;
  const top = h("div"), area = h("div");
  const list = () => data.items.filter((v) => (mode === "achievements" ? !!v.achievement : !!v.archivedAt === archived && !(mode === "manage" && v.achievement && v.stage === "completed" && false)) && (!fixedKind || fixedKind.includes(v.kind)) && (!f.kind || v.kind === f.kind) && (!f.health || v.health === f.health) && (!f.q || (v.name + " " + v.summary).toLowerCase().includes(f.q)));
  const reload = async () => { data = await api("GET", "/ventures"); drawArea(); };
  const subsList = () => data.items.filter((v) => v.kind === "subsidiary" && !v.archivedAt && (boot.isSuper || v.team.includes(boot.me.id)));
  const canCreate = (mode === "manage" || mode === "subs") && (can("ventures.manage") || can("ventures.propose")) && (mode === "manage" || boot.isSuper || subsList().length > 0);

  const card = (v) => h("button", { class: "kcard", draggable: v.canEdit ? "true" : "false", ondragstart: (e) => e.dataTransfer.setData("text/plain", v.id), onclick: () => show(v.id) },
    h("div", { class: "row" }, h("b", { class: "grow" }, v.name), h("span", { class: "pill" }, kindLabel(v))),
    v.summary && h("div", { class: "t" }, v.summary), h("div", { class: "meter" }, h("i", { style: `width:${v.progress}%` })),
    h("div", { class: "f" }, team(v.team, 3), timelinePill(v)));
  const row = (v) => h("button", { class: "tr", onclick: () => show(v.id) },
    h("div", { class: "cell" }, h("b", {}, v.name), h("div", { class: "tiny muted" }, kindLabel(v) + (v.parentName ? " of " + v.parentName : "") + (v.achievement ? " · ★ Achievement" : ""))),
    h("div", { class: "cell" }, stageLabel(v.stage)), h("div", { class: "cell" }, h("span", { class: "pill " + healthCls[v.health] }, healthLabel(v.health))),
    h("div", { class: "cell", style: "overflow:visible" }, h("div", { class: "tiny muted", style: "margin-bottom:4px" }, `${v.startDate || "…"} → ${v.targetDate || "…"}`), timelinePill(v)),
    h("div", { class: "cell", style: "overflow:visible" }, spentBar(v)), h("div", { class: "cell" }, team(v.team, 3)));

  const srow = (v) => h("button", { class: "tr", onclick: () => show(v.id) },
    h("div", { class: "cell" }, h("b", {}, v.name), h("div", { class: "tiny muted" }, kindLabel(v) + (v.parentName ? " of " + v.parentName : ""))),
    h("div", { class: "cell" }, money(v.revenue)), h("div", { class: "cell" }, money(v.cost + v.salary)), h("div", { class: "cell" }, v.loss ? h("span", { class: "pill bad" }, money(v.loss)) : money(0)),
    h("div", { class: "cell" }, h("b", { style: "color:var(--" + (v.profit < 0 ? "bad" : "ok") + ")" }, money(v.profit))), h("div", { class: "cell" }, team(v.team, 3)));
  function draw() {
    top.replaceChildren(h("div", { class: "toolbar" },
      h("input", { class: "search", type: "search", placeholder: "Search", "aria-label": "Search", value: f.q, oninput: (e) => { f.q = e.target.value.trim().toLowerCase(); drawArea(); } }),
      !fixedKind && h("select", { "aria-label": "Type", onchange: (e) => { f.kind = e.target.value; drawArea(); } }, [["", "Everything"], ["project", "Projects"], ["subsidiary", "Subsidiaries"], ["branch", "Branches"]].map(([v, l]) => h("option", { value: v }, l))),
      h("select", { "aria-label": "Health", onchange: (e) => { f.health = e.target.value; drawArea(); } }, [h("option", { value: "" }, "Any health"), ...boot.health.map((x) => h("option", { value: x.id }, x.label))]),
      h("div", { class: "grow" }), mode === "manage" && segmented([["board", "Board", "board"], ["list", "List", "rows"]], view, (v) => { view = v; drawArea(); }),
      canCreate && h("button", { class: "btn", onclick: () => projectForm(null, (r) => { if (r.venture) { reload().then(() => show(r.venture.id)); } else reload(); }, { mode, subs: subsList() }) }, icon("plus", "sm"), boot.isSuper ? "New" : "Propose")));
    drawArea();
  }
  function drawArea() {
    const l = list();
    if (!l.length) return area.replaceChildren(empty(archived ? "Archive is empty" : mode === "achievements" ? "No achievements yet" : "Nothing here yet", archived ? "Archived projects and subsidiaries stay here, nothing is lost." : mode === "achievements" ? "When a project is completed, file it here from its page." : canCreate ? "Create the first one with the New button." : ""));
    if (view === "board") area.replaceChildren(h("div", { class: "board" }, boot.stages.map((st) => { const items = l.filter((v) => v.stage === st.id);
      const col = h("div", { class: "col", ondragover: (e) => { e.preventDefault(); col.classList.add("over"); }, ondragleave: () => col.classList.remove("over"),
        ondrop: run(async (e) => { e.preventDefault(); col.classList.remove("over"); const id = e.dataTransfer.getData("text/plain"), v = data.items.find((x) => x.id === id); if (v?.canEdit && v.stage !== st.id) { await api("PATCH", "/ventures/" + id, { stage: st.id }); toast("Moved to " + st.label); reload(); } }) },
        h("h3", {}, st.label, h("span", { class: "muted" }, items.length)), items.map(card)); return col; })));
    else if (mode === "subs") area.replaceChildren(h("div", { class: "table stable" }, h("div", { class: "thead" }, ["Subsidiary / branch", "Revenue", "Cost + salary", "Loss", "Profit", "Team"].map((t) => h("div", {}, t))), l.map(srow)));
    else area.replaceChildren(h("div", { class: "table ptable" }, h("div", { class: "thead" }, ["Name", "Stage", "Health", "Timeline", "Budget used", "Team"].map((t) => h("div", {}, t))), l.map(row)));
  }

  /* ----- one project ----- */
  async function show(id) {
    ctl?.close(); const title = h("div"), body = h("div", { class: "db" });
    ctl = drawer(title, body, { onClose: () => { ctl = null; if (/^#\/(projects|subsidiaries|achievements|tracker|archive)\//.test(location.hash)) history.replaceState(null, "", "#/" + location.hash.split("/")[1]); } });
    history.replaceState(null, "", `#/${location.hash.split("/")[1] || "projects"}/${id}`);
    const render = async (v) => {
      v ||= await api("GET", "/ventures/" + id);
      const edit = v.canEdit, sel = (list, val, key) => h("select", { disabled: !edit, onchange: run(async (e) => { await api("PATCH", "/ventures/" + id, { [key]: e.target.value }); toast("Updated"); await reload(); render(); }) }, list.map((x) => h("option", { value: x.id, selected: x.id === val }, x.label)));
      title.replaceChildren(h("h2", {}, v.name), h("div", { class: "row wrap", style: "margin-top:6px" }, h("span", { class: "pill" }, kindLabel(v) + (v.parentName ? " of " + v.parentName : "")), v.achievement && h("span", { class: "pill ok" }, "★ Achievement"), h("span", { class: "pill " + healthCls[v.health] }, healthLabel(v.health)), timelinePill(v), v.pendingChanges ? h("span", { class: "pill info" }, `${v.pendingChanges} change${v.pendingChanges > 1 ? "s" : ""} awaiting authentication`) : null, v.archivedAt && h("span", { class: "pill" }, "Archived")));
      const bar = h("div", { class: "pbar" }, h("i", { style: `width:${v.progress}%` }));
      const prog = h("input", { type: "number", min: 0, max: 100, value: v.progress, disabled: !edit, style: "max-width:90px", onchange: run(async (e) => { await api("PATCH", "/ventures/" + id, { progress: Number(e.target.value) }); toast("Updated"); await reload(); render(); }) });
      const entryFields = (e = {}) => { const type = h("select", {}, ENTRY.map(([k, l]) => h("option", { value: k, selected: e.type === k }, l))), amt = h("input", { type: "number", min: 0, placeholder: "Amount", value: e.amount ?? "" }), lab = h("input", { type: "text", placeholder: "What it is", value: e.label || "" }), why = h("input", { type: "text", placeholder: "Reason (required)", value: e.reason || "" }), date = h("input", { type: "date", value: e.t ? new Date(e.t).toISOString().slice(0, 10) : "" });
        return { type, amt, lab, why, date, body: () => ({ type: type.value, amount: Number(amt.value), label: lab.value, reason: why.value, date: date.value }) }; };
      const ledgerForm = () => { const f = entryFields(); [f.type, f.amt, f.lab, f.date].forEach((x) => { x.style.cssText = "flex:1;min-width:120px;width:auto"; }); f.why.style.cssText = "flex:2;min-width:180px;width:auto";
        return h("div", { class: "row wrap", style: "margin-top:10px" }, f.type, f.amt, f.lab, f.why, f.date, h("button", { class: "btn sm", onclick: run(async () => { const r = await api("POST", `/ventures/${id}/ledger`, f.body()); toast(f.type.value === "withdrawal" ? "Added. The super account was notified." : "Added"); await reload(); render(r); }) }, "Add")); };
      const editEntry = (e) => { const f = entryFields(e), dlg = overlay([h("h2", {}, "Update transaction"), h("p", { class: "muted small" }, "The earlier values are kept in its history and the super account is told about the change."), h("div", { class: "grid g2" }, field("Type", f.type), field("Amount", f.amt)), h("div", { class: "grid g2" }, field("What it is", f.lab), field("Date", f.date)), field("Reason for the change", f.why),
        h("div", { class: "foot" }, h("button", { class: "btn ghost", onclick: () => dlg.close() }, "Cancel"), h("button", { class: "btn", onclick: run(async () => { const r = await api("PATCH", `/ventures/${id}/ledger/${e.id}`, f.body()); dlg.close(); toast("Updated"); await reload(); render(r); }) }, "Save"))]); };
      const kids = data.items.filter((c) => c.parentId === v.id), cons = kids.length ? kids.reduce((a, c) => ({ revenue: a.revenue + c.revenue, cost: a.cost + c.cost + c.salary, loss: a.loss + c.loss, profit: a.profit + c.profit }), { revenue: v.revenue, cost: v.cost + v.salary, loss: v.loss, profit: v.profit }) : null;
      const kpis = [["Budget", money(v.budget)], ["Revenue", money(v.revenue)], ["Cost", money(v.cost)], ["Salary", money(v.salary)], ["Loss", money(v.loss)], ["Profit", money(v.profit), v.profit < 0 ? "bad" : "ok"], ["Withdrawn", money(v.withdrawal)], ["Balance", money(v.balance)]];
      const done = v.stage === "completed" && !v.archivedAt && !v.achievement && edit;
      const post = h("textarea", { rows: 2, placeholder: "Write an update for the team…" });
      body.replaceChildren(...[
        v.summary && h("p", { style: "margin-bottom:18px" }, v.summary),
        h("div", { class: "sect" }, h("h3", {}, "Status"), h("div", { class: "grid g3" }, field("Stage", sel(boot.stages, v.stage, "stage")), field("Health", sel(boot.health, v.health, "health")), field("Progress %", prog)), bar),
        h("div", { class: "sect" }, h("h3", {}, "Timeline"), h("div", { class: "row wrap small", style: "margin-bottom:10px" }, h("span", {}, `Start ${v.startDate || "not set"}`), h("span", { class: "muted" }, "→"), h("span", {}, `Target ${v.targetDate || "not set"}`)),
          v.milestones.length ? h("div", { class: "list" }, v.milestones.map((m) => h("label", { class: "check box li", style: "cursor:" + (edit ? "pointer" : "default") }, h("input", { type: "checkbox", checked: m.done, disabled: !edit, onchange: run(async (e) => { await api("POST", `/ventures/${id}/milestones/${m.id}`, { done: e.target.checked }); await reload(); render(); }) }), h("span", { class: "grow" }, m.title), h("span", { class: "muted small" }, m.date || "")))) : h("p", { class: "muted small" }, "No milestones yet.")),
        done && h("div", { class: "banner" }, icon("flag", "sm"), h("span", { class: "grow" }, "The work is complete. File it under Achievements, or archive it."), h("button", { class: "btn sm", onclick: run(async () => { const note = prompt("A line about what was achieved (optional)") ?? null; if (note === null) return; const r = await api("POST", `/ventures/${id}/achievement`, { note }); toast("Filed under Achievements ★"); await reload(); render(r); }) }, "★ Achievement"), h("button", { class: "btn ghost sm", onclick: run(async () => { const r = await api("PATCH", "/ventures/" + id, { archived: true }); sentMsg(r); await reload(); r.pending ? render(r.venture) : ctl.close(); }) }, "Archive")),
        v.achievement && h("div", { class: "banner" }, icon("flag", "sm"), h("span", { class: "grow" }, `Achievement · ${fmtDay(v.achievement.at)}${v.achievement.note ? " — " + v.achievement.note : ""}`)),
        h("div", { class: "sect" }, h("h3", {}, v.kind === "project" ? "Budget & money" : "Money · revenue, loss, profit, cost, salary"), h("div", { class: "grid g4", style: "margin-bottom:12px" }, kpis.map(([l, n, c]) => h("div", { class: "kpi", style: "padding:12px" }, h("div", { class: "n", style: "font-size:16px" + (c ? `;color:var(--${c})` : "") }, n), h("div", { class: "l" }, l)))),
          cons && h("div", { class: "banner" }, icon("chart", "sm"), h("span", { class: "grow" }, `With its ${kids.length} branch${kids.length > 1 ? "es" : ""}: revenue ${money(cons.revenue)} · cost + salary ${money(cons.cost)} · loss ${money(cons.loss)} · profit ${money(cons.profit)}`)), spentBar(v),
          edit && ledgerForm(), v.ledger.length ? h("div", { class: "list", style: "margin-top:10px" }, v.ledger.slice(0, 60).map((e) => h("div", { class: "li" }, h("span", { class: "pill " + (entryCls[e.type] || "") }, ENTRY.find((x) => x[0] === e.type)?.[1] || e.type), h("span", { class: "grow" }, h("b", {}, money(e.amount)), " ", h("span", { class: "small" }, e.label || ""), h("div", { class: "muted tiny" }, `${e.reason || "No reason recorded"} · ${e.by || ""}${e.edits?.length ? " · edited " + e.edits.length + "×" : ""}`)), h("span", { class: "muted tiny" }, fmtDay(e.t)), edit && h("button", { class: "ico-btn", "aria-label": "Update", onclick: () => editEntry(e) }, icon("edit", "sm")), edit && h("button", { class: "ico-btn", "aria-label": "Remove", onclick: run(async () => { if (!(await confirmBox("Remove this transaction?", "The super account is told. Prefer updating it if the amount or reason was wrong.", "Remove", true))) return; const r = await api("DELETE", `/ventures/${id}/ledger/${e.id}`); await reload(); render(r); }) }, icon("x", "sm"))))) : h("p", { class: "muted small", style: "margin-top:10px" }, "No transactions yet."),
          kids.length ? h("div", { style: "margin-top:14px" }, h("h3", {}, "Branches"), h("div", { class: "list" }, kids.map((c) => h("button", { class: "li", onclick: () => show(c.id) }, h("span", { class: "grow" }, h("b", {}, c.name), h("span", { class: "muted small" }, ` revenue ${money(c.revenue)} · profit ${money(c.profit)}`)), icon("chev", "sm"))))) : null),
        h("div", { class: "sect" }, h("h3", {}, "Assigned team"), v.team.length ? h("div", { class: "list" }, v.team.map((uid) => { const p = who(uid); return h("div", { class: "li" }, whoAvatar(uid), h("span", { class: "grow" }, h("b", {}, p?.name || "Team member"), h("span", { class: "muted small" }, p?.designation || ""))); })) : h("p", { class: "muted small" }, "No one is assigned yet.")),
        h("div", { class: "sect" }, h("h3", {}, "Updates"), edit && h("div", { class: "field" }, post, h("div", { style: "margin-top:8px" }, h("button", { class: "btn sm", onclick: run(async () => { const r = await api("POST", `/ventures/${id}/updates`, { text: post.value }); await reload(); render(r); }) }, "Post update"))),
          h("div", { class: "tl" }, [...v.updates].reverse().slice(0, 30).map((u) => h("div", {}, h("div", { class: u.auto ? "muted small" : "" }, u.text), h("div", { class: "tiny muted" }, `${u.byName || "System"} · ${ago(u.t)}`))))),
        (edit || v.canManage) && h("div", { class: "row wrap sect" }, edit && h("button", { class: "btn", onclick: () => projectForm(v, async (r) => { await reload(); render(r.venture); }, { mode }) }, icon("edit", "sm"), "Edit plan"),
          edit && h("button", { class: "btn ghost", onclick: run(async () => { const r = await api("PATCH", "/ventures/" + id, { archived: !v.archivedAt }); sentMsg(r); await reload(); r.pending ? render(r.venture) : ctl.close(); }) }, v.archivedAt ? "Restore from archive" : "Archive"),
          v.canManage && h("button", { class: "btn danger", onclick: run(async () => { if (!(await confirmBox("Delete “" + v.name + "”?", "Its updates, money entries and reports history go with it. Archive it instead to keep the record.", "Delete", true))) return; await api("DELETE", "/ventures/" + id); ctl.close(); toast("Deleted"); await reload(); }) }, "Delete"))].filter(Boolean));
    };
    try { await render(); } catch (e) { ctl?.close(); toast(e.message, true); }
  }
  main.append(pageHead(archived ? "Archive" : mode === "track" ? "Tracker" : mode === "subs" ? "Subsidiaries" : mode === "achievements" ? "Achievements" : "Projects", mode === "subs" ? "Subsidiaries and their branches. Revenue, cost, salary, loss, profit and withdrawals — every transaction with its reason." : mode === "achievements" ? "Completed projects, filed as achievements." : archived ? "Archived projects and subsidiaries." : mode === "track" ? "Every project and subsidiary at a glance. Open one to see its timeline, money and updates." : boot.isSuper ? "Create projects and subsidiaries, decide budget and timeline, and assign people." : "Projects you are on. Propose new ones — the super account authenticates them."), top, area);
  draw(); if (args[0]) show(args[0]);
  return () => ctl?.close();
}
