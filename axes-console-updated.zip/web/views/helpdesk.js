/* Ongoing → Ask support: any account can write to the company's support team and follow the answer. */
import { h, state, api, run, icon, toast, ago, fmtDate, pageHead, empty, field, overlay } from "/ui.js";

export default async function (main, args) {
  let list = await api("GET", "/support/mine"); const box = h("div"), open = new Set(args[0] ? [args[0]] : []);
  const reload = async () => { list = await api("GET", "/support/mine"); draw(); };
  const stText = { new: "Sent", open: "Being handled", waiting: "Answered", closed: "Closed" };
  function ask() {
    const d = { subject: "", message: "" }, dlg = overlay([h("h2", {}, "Ask support"), h("p", { class: "muted small" }, "The support team answers here. You get a notice when they reply."), field("Subject", h("input", { type: "text", oninput: (e) => { d.subject = e.target.value; } })), field("What do you need?", h("textarea", { rows: 6, oninput: (e) => { d.message = e.target.value; } })),
      h("div", { class: "foot" }, h("button", { class: "btn ghost", onclick: () => dlg.close() }, "Cancel"), h("button", { class: "btn", onclick: run(async () => { const t = await api("POST", "/support/ask", d); dlg.close(); toast("Sent to support ✓"); open.add(t.id); reload(); }) }, "Send"))], { wide: true });
  }
  function draw() {
    box.replaceChildren(list.length ? h("div", { class: "list" }, list.map((t) => { const more = h("textarea", { rows: 3, placeholder: "Add a message…" });
      return h("details", { class: "item", open: open.has(t.id), ontoggle: (e) => { e.target.open ? open.add(t.id) : open.delete(t.id); } }, h("summary", {}, h("span", { class: "grow" }, h("b", { class: "title" }, t.subject), h("span", { class: "muted small", style: "display:block" }, `${t.ref} · ${ago(t.updatedAt)}`)), h("span", { class: "pill st-" + t.status }, stText[t.status] || t.status)),
        h("div", { class: "body" }, h("div", { class: "thread" }, t.thread.map((m) => h("div", { class: "msg " + (m.dir === "out" ? "out" : "") }, h("small", {}, `${m.dir === "out" ? "Support · " : "You · "}${m.byName} · ${fmtDate(m.t)}`), m.text))),
          t.status !== "closed" && h("div", { class: "sect" }, more, h("div", { style: "margin-top:8px" }, h("button", { class: "btn sm", onclick: run(async () => { await api("POST", `/support/mine/${t.id}/followup`, { text: more.value }); toast("Sent ✓"); reload(); }) }, "Send message")))));
    })) : empty("No questions yet", "Need help? Ask the support team — they serve every employee, client and customer of the company."));
  }
  main.append(pageHead("Ask support", "Write to the company’s support team and follow their answer."), h("div", { class: "toolbar" }, h("div", { class: "grow" }), h("button", { class: "btn", onclick: ask }, icon("plus", "sm"), "New question")), box); draw();
}
