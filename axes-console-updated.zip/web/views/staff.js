/* Business → Hiring. Managers apply to Human Resources for a team member; HR creates the account; the super account authenticates it. */
import { h, state, api, run, icon, toast, ago, pageHead, empty, field, overlay, copy } from "/ui.js";
import { limitsEditor } from "/views/accounts.js";

const label = (id) => state.boot.designations.find((d) => d.id === id)?.label || id;
const pill = (r) => h("span", { class: "pill " + ({ open: "warn", handled: "ok", declined: "bad" }[r.status] || "") }, { open: "Waiting for HR", handled: "Handled", declined: "Declined" }[r.status]);

export default async function (main) {
  let data = await api("GET", "/staff"); const box = h("div"), top = h("div");
  const reload = async () => { data = await api("GET", "/staff"); draw(); };
  const apply = () => {
    const d = { designation: data.hire[0], need: "", ventureId: "", forName: "" };
    const kind = h("select", { onchange: (e) => { d.designation = e.target.value; } }, data.hire.map((x) => h("option", { value: x }, label(x)))), where = h("select", { onchange: (e) => { d.ventureId = e.target.value; } }, [h("option", { value: "" }, "— not tied to one —"), ...data.ventures.map((v) => h("option", { value: v.id }, v.name))]);
    const dlg = overlay([h("h2", {}, "Ask Human Resources for a team member"), h("div", { class: "banner" }, icon("stamp", "sm"), h("span", { class: "grow" }, "HR creates the account and the super account authenticates it. Then the person appears in your team list.")),
      field("Who do you need?", kind), field("For which project / subsidiary", where), field("Person you have in mind (optional)", h("input", { type: "text", oninput: (e) => { d.forName = e.target.value; } })), field("What will they do, and why?", h("textarea", { rows: 3, oninput: (e) => { d.need = e.target.value; } })),
      h("div", { class: "foot" }, h("button", { class: "btn ghost", onclick: () => dlg.close() }, "Cancel"), h("button", { class: "btn", onclick: run(async () => { await api("POST", "/staff", d); dlg.close(); toast("Sent to Human Resources ✓"); reload(); }) }, "Send request"))]);
  };
  const fulfil = (r) => {
    const d = { name: r.forName || "", username: "", email: "", skills: "", conditions: "", salary: 0 }, lim = limitsEditor(), bind = (k, type = "text", extra = {}) => h("input", { type, value: d[k] || "", ...extra, oninput: (e) => { d[k] = e.target.value; } });
    const dlg = overlay([h("h2", {}, `Create the ${label(r.designation)}`), h("p", { class: "muted small" }, `For ${r.byName}: ${r.need}`), !state.boot.isSuper && h("div", { class: "banner" }, icon("stamp", "sm"), h("span", { class: "grow" }, "The super account must authenticate the account before it exists.")),
      h("div", { class: "grid g2" }, field("Full name", bind("name")), field("Username (ID)", bind("username", "text", { autocapitalize: "none" }))), h("div", { class: "grid g2" }, field("E-mail", bind("email", "email")), field("Monthly salary (" + state.boot.currency + ")", bind("salary", "number", { min: 0 }))),
      field("Skills", bind("skills", "text", { placeholder: "comma separated" })), field("Conditions of employment", h("textarea", { rows: 2, oninput: (e) => { d.conditions = e.target.value; } })),
      h("details", { class: "item" }, h("summary", {}, h("span", { class: "title" }, "Limitations")), h("div", { class: "body" }, lim.el)),
      h("div", { class: "foot" }, h("button", { class: "btn ghost", onclick: () => dlg.close() }, "Cancel"), h("button", { class: "btn", onclick: run(async () => {
        const x = await api("POST", `/staff/${r.id}/fulfil`, { ...d, salary: { amount: Number(d.salary) || 0 }, limits: lim.value() }); dlg.close();
        if (x.pending) toast("Sent to the super account for authentication ✓"); else { const b = h("input", { type: "text", readonly: true, value: x.inviteUrl, onfocus: (e) => e.target.select() }); const y = overlay([h("h2", {}, "Account created"), h("p", {}, `Give ${x.username} this private link to choose a password (valid 3 days).`), h("div", { class: "row" }, b, h("button", { class: "btn", onclick: () => copy(x.inviteUrl, "Link copied") }, "Copy")), h("div", { class: "foot" }, h("button", { class: "btn", onclick: () => y.close() }, "Done"))]); }
        reload(); }) }, state.boot.isSuper ? "Create account" : "Send for authentication"))], { wide: true });
  };
  function draw() {
    top.replaceChildren(data.canApply ? h("div", { class: "toolbar" }, h("div", { class: "grow" }), h("button", { class: "btn", onclick: apply }, icon("plus", "sm"), "Ask HR for someone")) : null);
    box.replaceChildren(data.items.length ? h("div", { class: "list" }, data.items.map((r) => h("div", { class: "li", style: "align-items:flex-start;flex-wrap:wrap" }, h("span", { class: "grow" }, h("b", {}, label(r.designation)), h("span", { class: "muted small" }, ` · ${r.byName} · ${ago(r.createdAt)}`), h("div", { class: "small", style: "margin-top:4px" }, r.need), r.forName && h("div", { class: "muted tiny" }, "In mind: " + r.forName), r.note && h("div", { class: "muted tiny" }, `${r.handledBy}: ${r.note}`)), pill(r),
      data.hr && r.status === "open" && h("div", { class: "row" }, h("button", { class: "btn sm", onclick: () => fulfil(r) }, "Create account"), h("button", { class: "btn ghost sm", onclick: run(async () => { await api("POST", `/staff/${r.id}/decline`, { note: prompt("Reason (optional)") || "" }); reload(); }) }, "Decline")))))
      : empty("No hiring requests", data.canApply ? "Need a junior project manager or a branch manager? Ask Human Resources." : "Requests from managers appear here."));
  }
  main.append(pageHead("Hiring", data.hr ? "Requests from managers. Create the account; the super account authenticates it." : "Ask Human Resources for a team member and follow the request."), top, box); draw();
}
