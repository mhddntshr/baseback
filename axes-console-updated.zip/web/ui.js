/* Children that are false, null or undefined are skipped, so `cond && node` works everywhere. */
for (const m of ["replaceChildren", "append", "prepend"]) { const o = Element.prototype[m]; Element.prototype[m] = function (...a) { return o.apply(this, a.flat(2).filter((x) => x !== false && x != null && x !== true)); }; }
/* Shared helpers. Everything visitors or teammates type is inserted with textContent, never innerHTML. */
export const app = document.getElementById("app");
export const state = { me: null, boot: null, dirty: false, passwordFromEnv: false };
const BASE = "/api";

export function h(tag, attrs = {}, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (k.startsWith("on")) el.addEventListener(k.slice(2), v);
    else if (k === "class") el.className = v;
    else if (k === "value") el.value = v ?? "";
    else if (v === true) el.setAttribute(k, "");
    else if (v != null && v !== false) el.setAttribute(k, v);
  }
  const add = (c) => Array.isArray(c) ? c.forEach(add) : c != null && c !== false && el.append(c instanceof Node ? c : document.createTextNode(String(c)));
  kids.forEach(add);
  return el;
}
export const $ = (sel, root = document) => root.querySelector(sel);

/* ---------- icons (our own constants, safe to inject) ---------- */
const P = {
  home: '<path d="M3 11.5 12 4l9 7.5"/><path d="M5.5 10v9.5h13V10"/><path d="M10 19.5v-5h4v5"/>',
  inbox: '<path d="M3 13h5l1.5 3h5L16 13h5"/><path d="M5.5 5h13L21 13v6H3v-6z"/>',
  globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.7 2.8 4 5.8 4 9s-1.3 6.2-4 9c-2.7-2.8-4-5.8-4-9s1.3-6.2 4-9z"/>',
  image: '<rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="9" cy="10" r="1.6"/><path d="m4 18 5.5-5 4 3.5 2.5-2L20 18"/>',
  lock: '<rect x="4.5" y="10.5" width="15" height="10" rx="3"/><path d="M8 10.5V8a4 4 0 0 1 8 0v2.5"/>',
  users: '<circle cx="9" cy="8.5" r="3.5"/><path d="M2.5 20c.6-3.5 3.3-5.5 6.5-5.5s5.9 2 6.5 5.5"/><path d="M16 5.2a3.5 3.5 0 0 1 0 6.6M18 14.8c2 .6 3.2 2.3 3.5 5.2"/>',
  pulse: '<path d="M3 12h4l2.5-6 4 12 2.5-6H21"/>',
  card: '<rect x="2.5" y="5" width="19" height="14" rx="3"/><path d="M2.5 10h19M6.5 15h4"/>',
  mail: '<rect x="3" y="5" width="18" height="14" rx="3"/><path d="m3.5 7.5 8.5 6 8.5-6"/>',
  user: '<circle cx="12" cy="8.5" r="4"/><path d="M4.5 20.5c.8-4 3.8-6 7.5-6s6.7 2 7.5 6"/>',
  search: '<circle cx="11" cy="11" r="6.5"/><path d="m16 16 4.5 4.5"/>',
  bell: '<path d="M6 16.5V11a6 6 0 0 1 12 0v5.5l1.5 2h-15z"/><path d="M10 21h4"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2.5v2M12 19.5v2M4.6 4.6l1.4 1.4M18 18l1.4 1.4M2.5 12h2M19.5 12h2M4.6 19.4 6 18M18 6l1.4-1.4"/>',
  moon: '<path d="M20.5 14.2A8.5 8.5 0 0 1 9.8 3.5a8.5 8.5 0 1 0 10.7 10.7Z"/>',
  menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
  x: '<path d="m6 6 12 12M18 6 6 18"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  check: '<path d="m5 12.5 4.5 4.5L19 7.5"/>',
  chev: '<path d="m9 5 7 7-7 7"/>',
  up: '<path d="M12 16V4M7 9l5-5 5 5M4.5 20h15"/>',
  down: '<path d="M12 4v12M7 11l5 5 5-5M4.5 20h15"/>',
  trash: '<path d="M4 7h16M9 7V4.5h6V7M6.5 7l1 13h9l1-13"/>',
  star: '<path d="m12 3.5 2.6 5.5 6 .8-4.4 4.2 1.1 6-5.3-2.9-5.3 2.9 1.1-6L3.4 9.8l6-.8z"/>',
  folder: '<path d="M3 7.5A2.5 2.5 0 0 1 5.5 5h4l2 2.5h7A2.5 2.5 0 0 1 21 10v7.5a2.5 2.5 0 0 1-2.5 2.5h-13A2.5 2.5 0 0 1 3 17.5z"/>',
  link: '<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1"/><path d="M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>',
  copy: '<rect x="8.5" y="8.5" width="12" height="12" rx="3"/><path d="M15.5 8.5V6a2.5 2.5 0 0 0-2.5-2.5H6A2.5 2.5 0 0 0 3.5 6v7A2.5 2.5 0 0 0 6 15.5h2.5"/>',
  grid: '<rect x="3.5" y="3.5" width="7" height="7" rx="2"/><rect x="13.5" y="3.5" width="7" height="7" rx="2"/><rect x="3.5" y="13.5" width="7" height="7" rx="2"/><rect x="13.5" y="13.5" width="7" height="7" rx="2"/>',
  rows: '<path d="M4 6h16M4 12h16M4 18h16"/>',
  board: '<rect x="3.5" y="4" width="5" height="16" rx="1.8"/><rect x="10" y="4" width="5" height="10" rx="1.8"/><rect x="16.5" y="4" width="4" height="13" rx="1.8"/>',
  edit: '<path d="M4 20h4L19.5 8.5a2.8 2.8 0 0 0-4-4L4 16z"/><path d="m13.5 6.5 4 4"/>',
  out: '<path d="M14 4.5h4.5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1H14M10 8l-4 4 4 4M6 12h10"/>',
  shield: '<path d="M12 3 4.5 6v5.5c0 4.5 3 8 7.5 9.5 4.5-1.5 7.5-5 7.5-9.5V6z"/><path d="m9 12 2.2 2.2L15.5 10"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  file: '<path d="M6 3.5h8l4.5 4.5v12.5H6z"/><path d="M14 3.5V8h4.5"/>',
  send: '<path d="m3.5 11 17-7.5-4.5 17-4-6.5z"/><path d="m12 14 4-6.5"/>',
  hist: '<path d="M4 12a8 8 0 1 0 2.5-5.8L4 8.5"/><path d="M4 4v4.5h4.5M12 8v4.5l3 1.5"/>',
  cmd: '<path d="M9 6a3 3 0 1 0-3 3h12a3 3 0 1 0-3-3v12a3 3 0 1 0 3-3H6a3 3 0 1 0 3 3z"/>',
  dots: '<circle cx="5.5" cy="12" r="1.2"/><circle cx="12" cy="12" r="1.2"/><circle cx="18.5" cy="12" r="1.2"/>',
  tools: '<path d="M14.5 6.5a4 4 0 0 0 5 5L12 19a2.8 2.8 0 0 1-4-4z"/><path d="m14.5 6.5 2-2 3 3-2 2"/>',
  ext: '<path d="M14 4.5h5.5V10M19.5 4.5 11 13M9.5 6H6a1.5 1.5 0 0 0-1.5 1.5v10.5A1.5 1.5 0 0 0 6 19.5h10.5A1.5 1.5 0 0 0 18 18v-3.5"/>',
  chart: '<path d="M4 20V4M4 20h16"/><path d="m7.5 15 3.5-4 3 2.5 4.5-6"/>',
  tasks: '<rect x="4" y="3.5" width="16" height="17" rx="3"/><path d="m8 9 1.6 1.6L12.5 7.5M8 15.5l1.6 1.6 2.9-3.1M14.5 9.5H17M14.5 16H17"/>',
  book: '<path d="M5 4.5h11a3 3 0 0 1 3 3v12H8a3 3 0 0 1-3-3z"/><path d="M5 16.5a3 3 0 0 1 3-3h11"/>',
  note: '<path d="M5 3.5h11l3 3v14H5z"/><path d="M8.5 9.5h7M8.5 13h7M8.5 16.5h4"/>',
  brief: '<rect x="3" y="7" width="18" height="13" rx="3"/><path d="M9 7V5.5A1.5 1.5 0 0 1 10.5 4h3A1.5 1.5 0 0 1 15 5.5V7M3 12.5h18"/>',
  stamp: '<path d="M9 14.5V12a3 3 0 1 1 6 0v2.5l2.5 2.5v1.5h-11V17z"/><path d="M5 21h14"/>',
  headset: '<path d="M4.5 14v-2a7.5 7.5 0 0 1 15 0v2"/><rect x="3.5" y="13.5" width="4" height="6" rx="2"/><rect x="16.5" y="13.5" width="4" height="6" rx="2"/><path d="M18.5 19.5c0 1.4-1.6 2-4 2"/>',
  arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
  back: '<path d="M19 12H5M11 6l-6 6 6 6"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M12 3.5v2.2M12 18.3v2.2M3.5 12h2.2M18.3 12h2.2M6 6l1.6 1.6M16.4 16.4 18 18M6 18l1.6-1.6M16.4 7.6 18 6"/>',
  flag: '<path d="M5.5 21V4M5.5 5h11l-2 4 2 4h-11"/>',
};
export function icon(name, cls = "") { const s = document.createElementNS("http://www.w3.org/2000/svg", "svg"); s.setAttribute("viewBox", "0 0 24 24"); s.setAttribute("class", "i " + cls); s.setAttribute("aria-hidden", "true"); s.innerHTML = P[name] || ""; return s; }

/* ---------- network ---------- */
export class ApiError extends Error { constructor(m, status) { super(m); this.status = status; } }
export async function api(method, url, body, extra = {}) {
  const res = await fetch(BASE + url, {
    method, credentials: "same-origin",
    headers: { "X-Requested-With": "axes-admin", ...(body && !extra.raw ? { "Content-Type": "application/json" } : {}), ...(extra.headers || {}) },
    body: body ? (extra.raw ? body : JSON.stringify(body)) : undefined,
  });
  const ct = res.headers.get("content-type") || "";
  const data = ct.includes("json") ? await res.json().catch(() => ({})) : {};
  if (res.status === 401 && !/^\/(login|invite)/.test(url)) { window.dispatchEvent(new Event("axes:signedout")); throw new ApiError("Please sign in.", 401); }
  if (!res.ok) throw new ApiError(data.error || "Something went wrong.", res.status);
  return data;
}
export const run = (fn) => async (...a) => { try { return await fn(...a); } catch (e) { if (e.status !== 401) toast(e.message, true); } };

/* ---------- small formatters ---------- */
export const clone = (o) => JSON.parse(JSON.stringify(o));
export const fmtDate = (v) => new Date(v).toLocaleString([], { dateStyle: "medium", timeStyle: "short" });
export const fmtDay = (v) => new Date(v).toLocaleDateString([], { month: "short", day: "numeric" });
export const fmtSize = (n) => n >= 1e9 ? (n / 1e9).toFixed(1) + " GB" : n >= 1e6 ? (n / 1e6).toFixed(1) + " MB" : n > 0 ? Math.max(1, Math.round(n / 1e3)) + " KB" : "0 KB";
export const fmtMB = (mb) => mb >= 1024 ? +(mb / 1024).toFixed(1) + " GB" : mb + " MB";
export function ago(v) {
  const s = (Date.now() - new Date(v).getTime()) / 1000;
  if (s < 60) return "just now"; if (s < 3600) return Math.floor(s / 60) + " min ago"; if (s < 86400) return Math.floor(s / 3600) + " h ago";
  if (s < 86400 * 7) return Math.floor(s / 86400) + " d ago"; return fmtDay(v);
}
export const initials = (n) => String(n || "?").split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0].toUpperCase()).join("") || "?";
export const avatar = (name, cls = "", photo = "") => h("span", { class: "avatar " + cls, title: name || "" }, photo ? h("img", { src: photo, alt: "" }) : initials(name));
export const who = (id) => state.boot.people.find((p) => p.id === id);
export const whoAvatar = (id, cls = "sm") => { const p = who(id); return avatar(p?.name || "?", cls, p?.photo); };
export const statusLabel = (id) => state.boot.statuses.find((s) => s.id === id)?.label || id;
export const statusPill = (id) => h("span", { class: "pill dot st-" + id }, statusLabel(id));
export const rolePill = (label) => h("span", { class: "pill role-admin" }, label);
export const personName = (id) => who(id)?.name || "";
export const can = (cap) => state.boot.caps.includes(cap);

/* ---------- feedback ---------- */
let toastTimer;
export function toast(msg, bad) {
  $(".toast")?.remove();
  const t = h("div", { class: "toast" + (bad ? " err" : ""), role: bad ? "alert" : "status" }, msg);
  document.body.append(t); clearTimeout(toastTimer); toastTimer = setTimeout(() => t.remove(), bad ? 5500 : 2400);
}
export async function copy(text, msg = "Copied") { try { await navigator.clipboard.writeText(text); toast(msg); } catch { toast("Press Ctrl+C to copy", true); } }

/* ---------- dialogs ---------- */
export function overlay(content, { wide = false, onClose } = {}) {
  const close = () => { o.remove(); document.removeEventListener("keydown", key); onClose?.(); };
  const key = (e) => { if (e.key === "Escape") close(); };
  const o = h("div", { class: "overlay", onmousedown: (e) => e.target === o && close() }, h("div", { class: "dialog" + (wide ? " wide" : ""), role: "dialog", "aria-modal": "true" }, content));
  document.body.append(o); document.addEventListener("keydown", key);
  o.querySelector("input,textarea,select")?.focus();
  return { close, el: o };
}
export const confirmBox = (title, text, okLabel = "Confirm", danger = false) => new Promise((resolve) => {
  let done = false; const fin = (v) => { if (!done) { done = true; d.close(); resolve(v); } };
  const d = overlay([h("h2", {}, title), text && h("p", {}, text), h("div", { class: "foot" }, h("button", { class: "btn ghost", onclick: () => fin(false) }, "Cancel"), h("button", { class: "btn" + (danger ? " danger" : ""), onclick: () => fin(true) }, okLabel))], { onClose: () => fin(false) });
  d.el.querySelector(".foot .btn:last-child").focus();
});
export const askText = (title, label, value = "", okLabel = "Save") => new Promise((resolve) => {
  let done = false; const fin = (v) => { if (!done) { done = true; d.close(); resolve(v); } };
  const inp = h("input", { type: "text", value, "aria-label": label, placeholder: label, onkeydown: (e) => e.key === "Enter" && fin(inp.value.trim() || null) });
  const d = overlay([h("h2", {}, title), h("div", { class: "field" }, inp), h("div", { class: "foot" }, h("button", { class: "btn ghost", onclick: () => fin(null) }, "Cancel"), h("button", { class: "btn", onclick: () => fin(inp.value.trim() || null) }, okLabel))], { onClose: () => fin(null) });
  inp.focus(); inp.select();
});
export function drawer(head, body, { onClose } = {}) {
  const close = () => { w.remove(); document.removeEventListener("keydown", key); onClose?.(); };
  const key = (e) => { if (e.key === "Escape" && !document.querySelector(".overlay")) close(); };
  const w = h("div", { class: "drawer-wrap", onmousedown: (e) => e.target === w && close() },
    h("aside", { class: "drawer", role: "dialog", "aria-modal": "true" }, h("div", { class: "dh" }, h("div", { class: "grow" }, head), h("button", { class: "ico-btn", "aria-label": "Close", onclick: close }, icon("x"))), body));
  document.body.append(w); document.addEventListener("keydown", key);
  return { close, el: w };
}
export function menu(anchor, items) {
  document.querySelector(".menu")?.remove();
  const r = anchor.getBoundingClientRect();
  const m = h("div", { class: "menu", role: "menu", style: `top:${r.bottom + 8}px;right:${Math.max(8, innerWidth - r.right)}px` },
    items.map((it) => it === "-" ? h("hr") : it instanceof Node ? it : h(it.href ? "a" : "button", { role: "menuitem", href: it.href, onclick: () => { m.remove(); it.onclick?.(); } }, it.icon && icon(it.icon, "sm"), it.label)));
  const off = (e) => { if (!m.contains(e.target)) { m.remove(); document.removeEventListener("mousedown", off, true); } };
  setTimeout(() => document.addEventListener("mousedown", off, true));
  document.body.append(m); m.querySelector("button,a")?.focus();
}

/* ---------- page pieces ---------- */
export function setTitle(t) { const e = document.getElementById("ttl"); if (e) e.textContent = t; document.title = t + " · axes"; }
export const pageHead = (title, sub, ...actions) => { setTitle(title); return (sub || actions.length) ? h("div", { class: "page-head" }, h("div", {}, sub && h("p", {}, sub)), actions.length ? h("div", { class: "actions" }, ...actions) : null) : h("span"); };
export const empty = (title, text) => h("div", { class: "empty" }, h("b", {}, title), text);
export const field = (label, control, hint) => h("div", { class: "field" }, h("label", {}, label), control, hint && h("div", { class: "hint" }, hint));
export const toggle = (label, checked, onchange, disabled) => h("label", { class: "check" }, h("input", { type: "checkbox", checked, disabled, onchange: (e) => onchange(e.target.checked) }), label);
export function meter(used, total) {
  const pct = Math.min(100, total ? (used / total) * 100 : 0);
  return h("div", { class: "meter" + (pct > 90 ? " hot" : ""), role: "progressbar", "aria-valuenow": Math.round(pct), "aria-valuemin": 0, "aria-valuemax": 100 }, h("i", { style: `width:${pct}%` }));
}
export const segmented = (opts, value, onpick) => { const box = h("div", { class: "seg" }, opts.map(([v, l, ic]) => h("button", { "aria-pressed": String(v === value), "aria-label": l, onclick: () => { box.querySelectorAll("button").forEach((b, i) => b.setAttribute("aria-pressed", String(opts[i][0] === v))); onpick(v); } }, ic ? icon(ic, "sm") : l))); return box; };

/* ---------- charts (plain SVG, one ink colour) ---------- */
const NS = "http://www.w3.org/2000/svg";
const s = (tag, attrs = {}, ...kids) => { const e = document.createElementNS(NS, tag); for (const [k, v] of Object.entries(attrs)) e.setAttribute(k, v); kids.forEach((k) => e.append(k)); return e; };
export function barChart(days, unit = "") {
  const W = 640, H = 170, pad = 22, max = Math.max(3, ...days.map((d) => d.n)), bw = (W - 8) / days.length;
  const svg = s("svg", { class: "chart", viewBox: `0 0 ${W} ${H + pad}`, role: "img", "aria-label": `Last ${days.length} days, ${days.reduce((a, b) => a + b.n, 0)} ${unit}` });
  [0, .5, 1].forEach((f) => svg.append(s("line", { class: "axis", x1: 0, x2: W, y1: H - f * (H - 14), y2: H - f * (H - 14) })));
  days.forEach((d, i) => { const hh = Math.max(d.n ? 4 : 2, (d.n / max) * (H - 14)); const r = s("rect", { class: "bar" + (i === days.length - 1 ? " today" : ""), x: 4 + i * bw + bw * .16, y: H - hh, width: Math.max(2, bw * .68), height: hh, rx: Math.min(4, bw * .3) }); r.append(s("title", {}, document.createTextNode(`${fmtDay(d.d)} · ${d.n} ${unit}`))); svg.append(r); });
  [0, Math.floor(days.length / 2), days.length - 1].forEach((i, k) => { const t = s("text", { x: k === 0 ? 4 : k === 1 ? W / 2 : W - 4, y: H + 16, "text-anchor": k === 0 ? "start" : k === 1 ? "middle" : "end" }); t.textContent = fmtDay(days[i].d); svg.append(t); });
  return svg;
}
export function lineChart(days, unit = "") {
  const W = 640, H = 170, pad = 22, max = Math.max(3, ...days.map((d) => d.n)), step = (W - 8) / (days.length - 1);
  const pts = days.map((d, i) => [4 + i * step, H - (d.n / max) * (H - 18) - 4]);
  const svg = s("svg", { class: "chart", viewBox: `0 0 ${W} ${H + pad}`, role: "img", "aria-label": `Last ${days.length} days, ${days.reduce((a, b) => a + b.n, 0)} ${unit}` });
  [0, .5, 1].forEach((f) => svg.append(s("line", { class: "axis", x1: 0, x2: W, y1: H - f * (H - 14), y2: H - f * (H - 14) })));
  const d = pts.map((p, i) => (i ? "L" : "M") + p[0].toFixed(1) + " " + p[1].toFixed(1)).join(" ");
  svg.append(s("path", { class: "area", d: d + ` L${pts.at(-1)[0]} ${H} L${pts[0][0]} ${H} Z` }), s("path", { class: "line", d }));
  days.forEach((dd, i) => { const c = s("circle", { cx: pts[i][0], cy: pts[i][1], r: 7, fill: "transparent" }); c.append(s("title", {}, document.createTextNode(`${fmtDay(dd.d)} · ${dd.n} ${unit}`))); svg.append(c); });
  [0, Math.floor(days.length / 2), days.length - 1].forEach((i, k) => { const t = s("text", { x: k === 0 ? 4 : k === 1 ? W / 2 : W - 4, y: H + 16, "text-anchor": k === 0 ? "start" : k === 1 ? "middle" : "end" }); t.textContent = fmtDay(days[i].d); svg.append(t); });
  return svg;
}
export const delta = (now, prev) => { if (!prev && !now) return h("span", { class: "delta" }, "—"); if (!prev) return h("span", { class: "delta up" }, "new"); const p = Math.round(((now - prev) / prev) * 100); return h("span", { class: "delta " + (p > 0 ? "up" : p < 0 ? "down" : "") }, (p > 0 ? "▲ " : p < 0 ? "▼ " : "") + Math.abs(p) + "% vs last week"); };

/* ---------- unsaved changes ---------- */
export const touch = () => { state.dirty = true; const b = $(".savebar"); if (b) { b.querySelector(".msg").textContent = "Unsaved changes"; b.querySelector(".msg").className = "msg dirty"; b.querySelector(".save").disabled = false; b.querySelector(".discard").disabled = false; } };
window.addEventListener("beforeunload", (e) => { if (state.dirty) { e.preventDefault(); e.returnValue = ""; } });
