const $ = (id) => document.getElementById(id);
$("f").addEventListener("submit", async (e) => {
  e.preventDefault(); $("err").hidden = true;
  try {
    const r = await fetch("/api/public/support", { method: "POST", headers: { "Content-Type": "application/json", "X-Requested-With": "axes-admin" }, body: JSON.stringify({ audience: $("aud").value, name: $("name").value, email: $("email").value, subject: $("subject").value, message: $("message").value, website: $("website").value }) });
    const j = await r.json(); if (!r.ok) throw new Error(j.error || "Could not send.");
    $("f").hidden = true; $("ok").hidden = false; $("ok").textContent = `Thank you. We have your message (${j.ref || "received"}) and will reply by e-mail.`;
  } catch (x) { $("err").textContent = x.message; $("err").hidden = false; }
});
